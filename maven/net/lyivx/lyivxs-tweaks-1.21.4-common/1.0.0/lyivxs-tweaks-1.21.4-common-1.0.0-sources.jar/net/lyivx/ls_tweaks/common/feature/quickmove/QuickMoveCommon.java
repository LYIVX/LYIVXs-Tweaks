package net.lyivx.ls_tweaks.common.feature.quickmove;

import net.lyivx.ls_tweaks.common.feature.slotlock.SlotLockCommon;
import net.lyivx.ls_tweaks.common.network.QolNet;
import net.lyivx.ls_tweaks.common.util.QuickOpContext;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_3222;

/** Server handler for Shift-drag quick-move events, one slot at a time. */
public final class QuickMoveCommon {
    public static void handle(class_3222 player, QolNet.QuickMoveC2SPayload p) {
        if (player == null) return;
        var menu = player.field_7512;
        if (menu == null) return;
        int idx = p.slotIndex;
        if (idx < 0 || idx >= menu.field_7761.size()) return;
        class_1735 s = menu.field_7761.get(idx);

        // Respect player slot locks
        if (s.field_7871 instanceof class_1661 && SlotLockCommon.isLocked(player, s.method_34266())) return;

        if (s.method_7681()) {
            boolean stopQuick = net.lyivx.ls_tweaks.common.config.ConfigProvider.slotLockStopQuickMoves();
            boolean isPlayerSlot = s.field_7871 instanceof class_1661;
            boolean locked = isPlayerSlot && SlotLockCommon.isLocked(player, s.method_34266());
            if (stopQuick && locked) return; // respect config: do not move from locked
            try {
                QuickOpContext.enter();
                player.field_7512.method_7593(idx, 0, class_1713.field_7794, player);
            } finally {
                QuickOpContext.exit();
            }
        }
    }

    private QuickMoveCommon() {}
}


