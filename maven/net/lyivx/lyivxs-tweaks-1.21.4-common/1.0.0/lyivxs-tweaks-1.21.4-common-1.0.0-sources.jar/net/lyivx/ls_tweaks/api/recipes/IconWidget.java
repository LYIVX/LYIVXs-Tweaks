package net.lyivx.ls_tweaks.api.recipes;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_6880;

/**
 * Icon widget for rendering an item/block with optional bounds-based scaling.
 */
public class IconWidget {
    public final int x;
    public final int y;
    public final int width;
    public final int height;
    public final boolean autoScale;
    public final boolean centered;

    public final class_1799 stack;
    public final int recipeJsonIndex;
    private final Supplier<class_1799> stackSupplier;
    private final List<class_1799> stackList;
    private final class_1856 cyclingIngredient;
    private final int cyclingSalt;

    public IconWidget(int x, int y, class_1799 stack, int index) {
        this.x = x;
        this.y = y;
        this.width = 16;
        this.height = 16;
        this.autoScale = false;
        this.centered = false;
        this.stack = stack == null ? class_1799.field_8037 : stack.method_7972();
        this.recipeJsonIndex = Math.max(0, index);
        this.stackSupplier = null;
        this.stackList = null;
        this.cyclingIngredient = null;
        this.cyclingSalt = 0;
    }

    public IconWidget(int x, int y,
                      class_1799 stack, int index,
                      Supplier<class_1799> stackSupplier,
                      List<class_1799> stackList,
                      class_1856 cyclingIngredient,
                      int cyclingSalt) {
        this.x = x;
        this.y = y;
        this.width = 16;
        this.height = 16;
        this.autoScale = false;
        this.centered = false;
        this.stack = stack == null ? class_1799.field_8037 : stack.method_7972();
        this.recipeJsonIndex = Math.max(0, index);
        this.stackSupplier = stackSupplier;
        this.stackList = stackList;
        this.cyclingIngredient = cyclingIngredient;
        this.cyclingSalt = cyclingSalt;
    }

    public IconWidget(int x, int y, int width, int height, boolean centered,
                      class_1799 stack, int index,
                      Supplier<class_1799> stackSupplier,
                      List<class_1799> stackList,
                      class_1856 cyclingIngredient,
                      int cyclingSalt) {
        this.x = x;
        this.y = y;
        this.width = Math.max(1, width);
        this.height = Math.max(1, height);
        this.autoScale = true;
        this.centered = centered;
        this.stack = stack == null ? class_1799.field_8037 : stack.method_7972();
        this.recipeJsonIndex = Math.max(0, index);
        this.stackSupplier = stackSupplier;
        this.stackList = stackList;
        this.cyclingIngredient = cyclingIngredient;
        this.cyclingSalt = cyclingSalt;
    }

    public static IconWidget of(int x, int y, class_1799 stack, int index) {
        return new IconWidget(x, y, stack, index);
    }

    public static IconWidget of(int x, int y, int width, int height, class_1799 stack, int index) {
        return new IconWidget(x, y, width, height, false, stack, index, null, null, null, 0);
    }

    public static IconWidget of(int x, int y, int width, int height, class_1792 item, int index) {
        return new IconWidget(x, y, width, height, false, new class_1799(item), index, null, null, null, 0);
    }

    public static IconWidget of(int x, int y, int width, int height, class_6880<class_1792> holder, int index) {
        return new IconWidget(x, y, width, height, false, new class_1799(holder.comp_349()), index, null, null, null, 0);
    }

    public static IconWidget of(int x, int y, int width, int height, List<class_6880<class_1792>> holders, int index) {
        List<class_1799> stacks = new ArrayList<>();
        for (class_6880<class_1792> h : holders) stacks.add(new class_1799(h.comp_349()));
        return new IconWidget(x, y, width, height, false, class_1799.field_8037, index, null, stacks, null, 0);
    }

    public static IconWidget of(int x, int y, int width, int height, java.util.stream.Stream<class_6880<class_1792>> holders, int index) {
        List<class_1799> stacks = holders == null ? java.util.Collections.emptyList() : holders.map(h -> new class_1799(h.comp_349())).toList();
        return new IconWidget(x, y, width, height, false, class_1799.field_8037, index, null, stacks, null, 0);
    }

    public static IconWidget of(int x, int y, int width, int height, class_1856 ingredient, int index, int salt) {
        return new IconWidget(x, y, width, height, false, class_1799.field_8037, index, null, null, ingredient, salt);
    }

    public void render(class_332 g, class_327 font, int baseX, int baseY) {
        int drawX = baseX + this.x;
        int drawY = baseY + this.y;

        class_1799 toRender;
        if (this.stackSupplier != null) {
            try {
                class_1799 supplied = this.stackSupplier.get();
                toRender = supplied == null ? class_1799.field_8037 : supplied;
            } catch (Throwable t) {
                toRender = class_1799.field_8037;
            }
        } else if (this.stackList != null) {
            int idx = Math.max(0, this.recipeJsonIndex);
            toRender = (idx < this.stackList.size() && this.stackList.get(idx) != null) ? this.stackList.get(idx) : class_1799.field_8037;
        } else if (this.cyclingIngredient != null) {
            toRender = getCyclingItem(this.cyclingIngredient, this.cyclingSalt);
        } else {
            toRender = this.stack;
        }

        if (this.autoScale) {
            float scaleX = this.width / 16.0f;
            float scaleY = this.height / 16.0f;
            float scale = Math.min(scaleX, scaleY);
            int offsetX = 0;
            int offsetY = 0;
            if (this.centered) {
                int contentW = Math.round(16 * scale);
                int contentH = Math.round(16 * scale);
                offsetX = (this.width - contentW) / 2;
                offsetY = (this.height - contentH) / 2;
            }
            g.method_51448().method_22903();
            g.method_51448().method_46416(drawX + offsetX, drawY + offsetY, 0);
            g.method_51448().method_22905(scale, scale, 1.0f);
            g.method_51427(toRender, 0, 0);
            g.method_51431(font, toRender, 0, 0);
            g.method_51448().method_22909();
        } else {
            g.method_51427(toRender, drawX, drawY);
            g.method_51431(font, toRender, drawX, drawY);
        }

        // Note: Tooltips for icons are handled by parent containers; no direct hover logic here.
    }

    private static class_1799 getCyclingItem(class_1856 ingredient, int salt) {
        try {
            var mc = net.minecraft.class_310.method_1551();
            long t = (mc != null && mc.field_1687 != null) ? mc.field_1687.method_8510() : 0L;
            var holders = ingredient.method_8105().toList();
            if (holders.isEmpty()) return class_1799.field_8037;
            int idx = (int)(((t / 20L) + Math.max(0, salt)) % holders.size());
            return new class_1799(holders.get(idx).comp_349());
        } catch (Throwable ignored) {}
        return class_1799.field_8037;
    }
}


