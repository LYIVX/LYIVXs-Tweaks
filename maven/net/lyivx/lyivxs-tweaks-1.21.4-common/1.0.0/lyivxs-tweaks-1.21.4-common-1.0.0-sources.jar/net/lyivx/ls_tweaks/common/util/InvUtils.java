package net.lyivx.ls_tweaks.common.util;

import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_7923;

public final class InvUtils {

    public static class_1799 findMatchingInBackpack(class_1657 player, class_1799 signature, boolean strict) {
        var inv = player.method_31548();

        for (int i = 9; i < inv.field_7547.size(); i++) {
            var st = inv.field_7547.get(i);
            if (matches(st, signature, strict)) {
                return st;
            }
        }
        for (int i = 0; i < 9; i++) {
            var st = inv.field_7547.get(i);
            if (matches(st, signature, strict)) {
                return st;
            }
        }
        return class_1799.field_8037;
    }

    public static boolean matches(class_1799 stack, class_1799 signature, boolean strict) {
        if (stack.method_7960() || signature.method_7960()) return false;
        if (strict) {
            return class_1799.method_31577(stack, signature);
        } else {
            return class_7923.field_41178.method_10221(stack.method_7909())
                    .equals(class_7923.field_41178.method_10221(signature.method_7909()));
        }
    }

    public static boolean moveIntoHotbarSlot(class_1657 player, class_1799 source, int hotbarSlot) {
        if (source.method_7960() || hotbarSlot < 0 || hotbarSlot > 8) return false;

        var inv = player.method_31548();
        class_1799 target = inv.method_5438(hotbarSlot);

        if (target.method_7960()) {
            inv.method_5447(hotbarSlot, source.method_7972());
            source.method_7939(0);
            inv.method_5431();
            player.field_7512.method_7623();
            return true;
        } else if (class_1799.method_31577(source, target)) {
            int canMove = Math.min(source.method_7947(), target.method_7914() - target.method_7947());
            if (canMove > 0) {
                target.method_7933(canMove);
                source.method_7934(canMove);
                inv.method_5431();
                player.field_7512.method_7623();
                return true;
            }
        }
        return false;
    }
}