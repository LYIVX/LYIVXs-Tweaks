package net.lyivx.ls_tweaks.api.recipes;

import java.util.Set;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_3956;

/**
 * A category that is directly backed by a concrete Minecraft recipe type.
 * Implementations provide the recipe class and type so the browser can enumerate
 * recipes without reflection helpers.
 */
public interface RecipeBackedCategory<T extends class_1860<?>> extends RecipeCategory<T> {
    /** Concrete recipe class handled by this category. */
    Class<T> recipeClass();

    /** Backing recipe type used to enumerate recipes. */
    class_3956<T> recipeType();

    /** Optional filter of serializers accepted by this category (may be empty for "all"). */
    default Set<class_1865<? extends T>> allowedSerializers() { return java.util.Set.of(); }
}


