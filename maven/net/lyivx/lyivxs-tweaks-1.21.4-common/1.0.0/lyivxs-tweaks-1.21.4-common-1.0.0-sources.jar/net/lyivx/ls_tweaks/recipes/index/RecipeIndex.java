package net.lyivx.ls_tweaks.recipes.index;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.lyivx.ls_tweaks.recipes.util.DisplayUtil;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1863;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_6880;
import net.minecraft.class_8786;
import net.minecraft.class_9887;

/**
 * Efficient lookups for recipes by result (show recipe) and by ingredient (show usages).
 * Built from the world's RecipeManager. Call rebuild() on world join/data reload.
 */
public final class RecipeIndex {
    private static final Map<String, List<class_8786<?>>> BY_RESULT_ID = new ConcurrentHashMap<>();
    private static final Map<String, List<class_8786<?>>> BY_INGREDIENT_ID = new ConcurrentHashMap<>();
    
    /** Build on-demand; avoid rebuilding on every click. */
    public static void ensureBuilt() {
        if (BY_RESULT_ID.isEmpty() || BY_INGREDIENT_ID.isEmpty()) {
            boolean haveRM = clientRecipeManager() != null;
            boolean haveRA = clientRegistryAccessAvailable();
            if (haveRM || haveRA) {
                System.out.println("[LS Tweaks][RV] RecipeIndex.ensureBuilt: rebuilding indices");
                rebuild();
            } else {
                System.out.println("[LS Tweaks][RV] RecipeIndex.ensureBuilt: deferring rebuild (no RecipeManager/RegistryAccess)");
            }
        }
    }

    public static void rebuild() {
        BY_RESULT_ID.clear();
        BY_INGREDIENT_ID.clear();
        class_1863 mgr = clientRecipeManager();
        if (mgr == null) return;

        int count = 0;
        final int[] dbg = new int[]{0};
        java.util.function.Consumer<class_8786<?>> indexHolder = holder -> {
            class_1860<?> r = holder.comp_1933();
            // Use display-backed result (fast) and placementInfo ingredients
            class_1799 out = DisplayUtil.firstOutput(holder);
            if (!out.method_7960()) {
                for (String key : keysOf(out)) BY_RESULT_ID.computeIfAbsent(key, k -> new ArrayList<>()).add(holder);
            }
            try {
                var info = r.method_61671();
                if (info != null && info.method_64675() != null) {
                    int i = 0;
                    for (var ing : info.method_64675()) {
                        if (ing == null) { i++; continue; }
                        for (var h : ing.method_8105().toList()) {
                            class_1799 s = new class_1799(h.comp_349());
                            if (s.method_7960()) continue;
                            for (String ikey : keysOf(s)) BY_INGREDIENT_ID.computeIfAbsent(ikey, k -> new ArrayList<>()).add(holder);
                            dbg[0]++;
                        }
                        i++;
                    }
                }
            } catch (Throwable ignored) {}
        };

        for (class_8786<?> holder : mgr.method_8126()) { indexHolder.accept(holder); count++; }
        // Removed JsonRecipeIndex fallback - using working recipe system only
        System.out.println("[LS Tweaks][RV] Index built: recipes=" + count + " resultsKeys=" + BY_RESULT_ID.size() + " ingredientKeys=" + BY_INGREDIENT_ID.size() + " totalIngredients=" + dbg[0]);
    }

    public static List<class_8786<?>> recipesFor(class_1799 result) {
        if (result == null || result.method_7960()) return List.of();
        List<class_8786<?>> out = BY_RESULT_ID.getOrDefault(keyOf(result), List.of());
        if (!out.isEmpty()) return out;
        java.util.List<String> alt = keysOf(result);
        for (String k : alt) {
            out = BY_RESULT_ID.getOrDefault(k, List.of());
            if (!out.isEmpty()) return out;
        }
        // Slow fallback: match by base item only (ignore NBT/components like dye color)
        // Removed heavy fallback that depended on old RecipeUtil
        try {
            System.out.println("[LS Tweaks][RV] recipesFor miss: keys=" + alt + " primary=" + keyOf(result) + " resultsKeysSize=" + BY_RESULT_ID.size());
        } catch (Throwable ignored) {}
        return List.of();
    }

    public static List<class_8786<?>> usagesFor(class_1799 ingredient) {
        if (ingredient == null || ingredient.method_7960()) return List.of();
        String key = keyOf(ingredient);
        List<class_8786<?>> result = BY_INGREDIENT_ID.getOrDefault(key, List.of());
        if (result.isEmpty()) {
            for (String k : keysOf(ingredient)) {
                result = BY_INGREDIENT_ID.getOrDefault(k, List.of());
                if (!result.isEmpty()) break;
            }
        }
        System.out.println("[LS Tweaks][RV] usagesFor(" + ingredient.method_7964().getString() + ") key=" + key + " altHit=" + (!result.isEmpty()) + " found=" + result.size() + " totalIngredientKeys=" + BY_INGREDIENT_ID.size());
        return result;
    }
    
    public static List<class_8786<?>> getAllRecipes() {
        List<class_8786<?>> allRecipes = new ArrayList<>();
        allRecipes.addAll(BY_RESULT_ID.values().stream().flatMap(List::stream).distinct().toList());
        allRecipes.addAll(BY_INGREDIENT_ID.values().stream().flatMap(List::stream).distinct().toList());
        return allRecipes.stream().distinct().toList();
    }

    private static String keyOf(class_1799 stack) {
        return stack.method_41409().method_40230().map(k -> k.method_29177().toString()).orElse(stack.method_7964().getString());
    }

    private static java.util.List<String> keysOf(class_1799 stack) {
        java.util.List<String> keys = new java.util.ArrayList<>();
        try {
            stack.method_41409().method_40230().ifPresent(k -> keys.add(k.method_29177().toString()));
        } catch (Throwable ignored) {}
        try {
            String hover = stack.method_7964().getString();
            if (hover != null && !hover.isBlank()) keys.add(hover);
        } catch (Throwable ignored) {}
        try {
            String desc = stack.method_7909().method_7876();
            if (desc != null && !desc.isBlank()) keys.add(desc);
        } catch (Throwable ignored) {}
        // Normalize variants: lowercase
        for (int i = 0; i < keys.size(); i++) keys.set(i, keys.get(i));
        return keys;
    }

    private RecipeIndex() {}

    private static class_1863 clientRecipeManager() {
        try {
            var mc = class_310.method_1551();
            if (mc == null) return null;
            Object server = mc.method_1576();
            if (server != null) {
                try { var m = server.getClass().getMethod("getRecipeManager"); Object rm = m.invoke(server); if (rm instanceof class_1863 r) return r; } catch (Throwable ignored) {}
            }
            var conn = mc.method_1562();
            if (conn != null) {
                try { var m = conn.getClass().getMethod("getRecipeManager"); Object rm = m.invoke(conn); if (rm instanceof class_1863 r) return r; } catch (Throwable ignored) {}
                for (var m : conn.getClass().getMethods()) {
                    if (m.getParameterCount() == 0 && class_1863.class.isAssignableFrom(m.getReturnType())) {
                        try { Object rm = m.invoke(conn); if (rm instanceof class_1863 r) return r; } catch (Throwable ignored) {}
                    }
                }
            }
        } catch (Throwable ignored) {}
        return null;
    }

    private static boolean clientRegistryAccessAvailable() {
        try {
            var mc = class_310.method_1551();
            return mc != null && mc.field_1687 != null && mc.field_1687.method_30349() != null;
        } catch (Throwable ignored) {}
        return false;
    }
}


