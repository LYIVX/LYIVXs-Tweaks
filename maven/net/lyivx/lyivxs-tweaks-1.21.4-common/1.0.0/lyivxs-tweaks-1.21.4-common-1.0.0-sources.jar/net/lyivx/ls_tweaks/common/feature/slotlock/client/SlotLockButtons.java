package net.lyivx.ls_tweaks.common.feature.slotlock.client;

import net.lyivx.ls_tweaks.common.config.ConfigProvider;
import net.lyivx.ls_tweaks.common.feature.slotlock.SlotLockClient;
import net.lyivx.ls_tweaks.common.ui.IconButton;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_481;
import net.minecraft.class_490;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public final class SlotLockButtons {
    private SlotLockButtons() {}

    private static class_2960 tex(String name, boolean hl) {
        String file = name + (hl ? "_highlight" : "") + ".png";
        return class_2960.method_60655("ls_tweaks", "textures/gui/widgets/" + file);
    }

    public static List<IconButton> create(class_437 screen) {
        List<IconButton> out = new ArrayList<>();
        if (!ConfigProvider.slotLockEnabled()) return out;
        if (!(screen instanceof class_465<?> cs)) return out;
        // Show on any screen containing the player's inventory (including containers and creative/inventory)

        final int bw = 12, bh = 10, rightGap = 2, slotSize = 18;
        class_1735 s = findPlayerSlot(cs, 17);
        if (s == null) return out;
        int left = getLeft(cs), top = getTop(cs);
        int x = left + s.field_7873 + slotSize + rightGap;
        int y = top + s.field_7872 + ((slotSize - bh) / 2) - 17;

        var btn = new IconButton(
                x, y, bw, bh,
                tex("lock_toggle_button", false), tex("lock_toggle_button", true),
                tooltip(),
                b -> {
                    SlotLockClient.toggleMode();
                    var mc = class_310.method_1551();
                    if (mc != null && mc.field_1724 != null)
                        mc.field_1724.method_7353(class_2561.method_43470("Slot Lock " + (SlotLockClient.isModeEnabled() ? "Enabled" : "Disabled")), true);
                    b.method_47400(net.minecraft.class_7919.method_47407(tooltip()));
                }
        );
        out.add(btn);
        return out;
    }

    private static boolean isPlayerInventory(class_437 s) {
        return (s instanceof class_490) || (s instanceof class_481);
    }
    private static class_2561 tooltip() {
        return class_2561.method_43470("Slot Lock: " + (SlotLockClient.isModeEnabled() ? "ON" : "OFF") + "\nCtrl+Middle-Click a player slot");
    }
    private static class_1735 findPlayerSlot(class_465<?> cs, int containerSlot) {
        for (class_1735 sl : cs.method_17577().field_7761) if (sl.field_7871 instanceof class_1661 && sl.method_34266() == containerSlot) return sl;
        return null;
    }
    private static int getLeft(class_465<?> cs) {
        try { var f = class_465.class.getDeclaredField("leftPos"); f.setAccessible(true); return f.getInt(cs); } catch (Throwable ignored) { return (cs.field_22789 - 176) / 2; }
    }
    private static int getTop(class_465<?> cs) {
        try { var f = class_465.class.getDeclaredField("topPos"); f.setAccessible(true); return f.getInt(cs); } catch (Throwable ignored) { return (cs.field_22790 - 166) / 2; }
    }
}


