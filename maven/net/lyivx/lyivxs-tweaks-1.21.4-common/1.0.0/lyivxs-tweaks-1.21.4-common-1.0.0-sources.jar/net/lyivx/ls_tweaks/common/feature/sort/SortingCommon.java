package net.lyivx.ls_tweaks.common.feature.sort;

import net.lyivx.ls_tweaks.common.config.ConfigProvider;
import net.lyivx.ls_tweaks.common.debug.QolDebug;
import net.lyivx.ls_tweaks.common.network.QolNet;
import net.lyivx.ls_tweaks.common.util.QuickOpContext;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1723;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import java.util.ArrayList;
import java.util.List;

public final class SortingCommon {

    public static void onSortRequest(class_3222 sp, QolNet.SortC2SPayload req) {
        if (!ConfigProvider.sortingEnabled()) return;

        switch (req.target()) {
            case PLAYER -> sortPlayerMainOnly(sp, req.mode(), req.mergeBeforeSort(), req.unstackablesLast());
            case CONTAINER -> sortOpenContainer(sp, req.mode(), req.mergeBeforeSort(), req.unstackablesLast());
        }
    }

    /** Sort ONLY main inventory (slots 9..35). Hotbar untouched. */
    private static void sortPlayerMainOnly(class_3222 sp, QolNet.SortC2SPayload.Mode mode, boolean merge, boolean unstackablesLast) {
        var inv = sp.method_31548();

        boolean respectLocks = ConfigProvider.slotLockStopQuickMoves();
        List<Integer> writable = new ArrayList<>(27);
        List<class_1799> area = new ArrayList<>(27);
        for (int i = 9; i <= 35; i++) {
            if (respectLocks && net.lyivx.ls_tweaks.common.feature.slotlock.SlotLockCommon.isLocked(sp, i) && !inv.method_5438(i).method_7960()) {
                // when respecting locks, keep locked slot’s current stack as-is; exclude from sorting area
                continue;
            }
            writable.add(i);
            area.add(inv.method_5438(i).method_7972());
        }

        QolDebug.log("Server: sorting PLAYER MAIN (9..35) mode=" + mode + " merge=" + merge + " unstackablesLast=" + unstackablesLast);
        List<class_1799> sorted = InventorySorter.sort(area, mode, merge, unstackablesLast);

        for (int j = 0; j < sorted.size(); j++) {
            int idx = writable.get(j);
            if (respectLocks && net.lyivx.ls_tweaks.common.feature.slotlock.SlotLockCommon.isLocked(sp, idx)) {
                // allow placing only if item matches remembered signature
                class_1799 st = sorted.get(j);
                if (st.method_7960()) continue;
                if (!net.lyivx.ls_tweaks.common.feature.slotlock.SlotLockCommon.allowsItem(sp, idx, st)) continue;
            }
            try { QuickOpContext.enter(); inv.method_5447(idx, sorted.get(j)); } finally { QuickOpContext.exit(); }
        }
        inv.method_5431();
        sp.field_7512.method_7623();
    }

    /** Sort the open container's own slots (not the player's inv slots appended to it). */
    private static void sortOpenContainer(class_3222 sp, QolNet.SortC2SPayload.Mode mode, boolean merge, boolean unstackablesLast) {
        class_1703 menu = sp.field_7512;
        if (menu == null) return;

        // If it's actually the player's inventory menu, redirect to player sort
        if (menu instanceof class_1723) {
            sortPlayerMainOnly(sp, mode, merge, unstackablesLast);
            return;
        }

        // Blocklisted containers: ignore
        if (!SortingWhitelist.isAllowed(menu, null)) {
            return;
        }

        var playerInv = sp.method_31548();
        List<class_1735> containerSlots = new ArrayList<>();
        for (class_1735 s : menu.field_7761) {
            if (s.field_7871 != playerInv && s.method_7682()) containerSlots.add(s);
        }
        if (containerSlots.isEmpty()) {
            return;
        }

        List<class_1799> area = new ArrayList<>(containerSlots.size());
        for (class_1735 s : containerSlots) area.add(s.method_7677().method_7972());

        List<class_1799> sorted = InventorySorter.sort(area, mode, merge, unstackablesLast);

        for (int i = 0; i < containerSlots.size(); i++) {
            class_1735 s = containerSlots.get(i);
            s.field_7871.method_5447(s.method_34266(), sorted.get(i));
        }
        menu.method_7623();
    }

    private SortingCommon() {}
}