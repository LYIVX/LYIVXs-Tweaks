package net.lyivx.ls_tweaks.common.feature.quickstack.client;

import net.lyivx.ls_tweaks.common.config.ConfigProvider;
import net.lyivx.ls_tweaks.common.feature.quickstack.QuickStackCommon;
import net.lyivx.ls_tweaks.common.feature.sort.SortingWhitelist;
import net.lyivx.ls_tweaks.common.feature.sort.client.SortingButtons;
import net.lyivx.ls_tweaks.common.network.QolNet;
import net.lyivx.ls_tweaks.common.ui.IconButton;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_481;
import net.minecraft.class_490;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public final class QuickStackButtons {

    private static final String BASE = "textures/gui/widgets/";
    private static class_2960 tex(String name, boolean hl) {
        String file = name + (hl ? "_highlight" : "") + ".png";
        return class_2960.method_60655("ls_tweaks", BASE + file);
    }
    public static List<IconButton> create(class_437 screen) {
        List<IconButton> out = new ArrayList<>();
        if (!ConfigProvider.quickStackEnabled()) return out;
        if (!ConfigProvider.uiShowQuickStackButtons()) return out;
        if (!(screen instanceof class_465<?> cs)) return out;

        boolean isPlayerInvUI = (screen instanceof class_490) || (screen instanceof class_481);
        boolean isContainerUI = !isPlayerInvUI;
        boolean containerAllowed = isContainerUI && SortingWhitelist.isAllowed(cs.method_17577(), cs);
        if (!containerAllowed && !isPlayerInvUI) return out;

        // --- CONSTANTS (match your SortingButtons sizing/gaps) ---
        final int bw = 12, bh = 10;
        final int slotSize = 18;
        final int gapAboveSlot = 4;
        final int gapRightOfSlot = 2;
        final int vGap = 8;
        final int stackGap = 2; // small extra gap between Sorting column and Quick-Stack column

        // --- We ALWAYS do a vertical column for Quick-Stack ---
        // Anchor to your INVENTORY column (same as Sorting does: above player slot 17)
        Anchor invAnchor = anchorRightOfPlayerSlot(cs, 17, bw, bh, gapRightOfSlot, slotSize);
        int x = invAnchor != null ? invAnchor.x() : 8;
        int y = invAnchor != null ? invAnchor.y() : 8;

        // If Sorting buttons are shown AND vertical, push Quick-Stack below them.
        if (ConfigProvider.sortingEnabled() && ConfigProvider.uiShowSortingButtons()) {
            int sortInventoryCount = SortingButtons.visibleInventoryColumnCount(screen);
            boolean sortVertical = SortingButtons.isInventoryColumnVertical(screen);
            if (sortInventoryCount > 0 && sortVertical) {
                y += sortInventoryCount * (bh + vGap) + stackGap;
            }
        }

        // --- Build Quick-Stack (Inventory → Container) ---
        out.add(new IconButton(
                x, y, bw, bh,
                tex("quickstack_inv_match_button", false), tex("quickstack_inv_match_button", true),
                class_2561.method_43470("Inventory → Container (Quick-Stack)"),
                btn -> send(QuickStackCommon.Direction.PLAYER_TO_CONTAINER, QuickStackCommon.Mode.MATCHING_ONLY)
        ));
        y += bh + vGap;
        out.add(new IconButton(
                x, y, bw, bh,
                tex("quickstack_inv_all_button", false), tex("quickstack_inv_all_button", true),
                class_2561.method_43470("Inventory → Container (Move All)"),
                btn -> send(QuickStackCommon.Direction.PLAYER_TO_CONTAINER, QuickStackCommon.Mode.MOVE_ALL)
        ));

        // --- Build Quick-Stack (Container → Inventory) stacked in its own column above container slot(s) ---
        if (containerAllowed) {
            Anchor contAnchor = anchorRightOfContainerIndex(cs, 8, bw, bh, gapRightOfSlot, slotSize);
            int cx = contAnchor != null ? contAnchor.x() : x; // fallback to inv column if weird screen
            int cy = contAnchor != null ? contAnchor.y() : (y + bh + vGap + stackGap);

            out.add(new IconButton(
                    cx, cy, bw, bh,
                    tex("quickstack_cont_match_button", false), tex("quickstack_cont_match_button", true),
                    class_2561.method_43470("Container → Inventory (Quick-Stack)"),
                    btn -> send(QuickStackCommon.Direction.CONTAINER_TO_PLAYER, QuickStackCommon.Mode.MATCHING_ONLY)
            ));
            cy += bh + vGap;
            out.add(new IconButton(
                    cx, cy, bw, bh,
                    tex("quickstack_cont_all_button", false), tex("quickstack_cont_all_button", true),
                    class_2561.method_43470("Container → Inventory (Move All)"),
                    btn -> send(QuickStackCommon.Direction.CONTAINER_TO_PLAYER, QuickStackCommon.Mode.MOVE_ALL)
            ));
        }

        return out;
    }


    // ----- Anchor helpers (same approach as SortingButtons) -----
        private record Anchor(int x, int y) {}

        private static Anchor anchorAbovePlayerSlot(class_465<?> cs, int playerSlotIndex,
                                                    int bw, int bh, int gapY, int slotSize) {
            var menu = cs.method_17577();
            var playerInv = getPlayerInventoryFromMenu(menu);
            if (playerInv == null) return null;
            class_1735 target = findSlot(menu, s -> s.field_7871 == playerInv && s.method_34266() == playerSlotIndex);
            if (target == null) return null;

            int left = guiLeft(cs), top = guiTop(cs);
            int slotAbsX = left + target.field_7873, slotAbsY = top + target.field_7872;
            int x = (slotAbsX + (slotSize - bw) / 2) - 1;
            int y = slotAbsY - (bh + gapY);
            return new Anchor(x, y);
        }

        private static Anchor anchorRightOfPlayerSlot(class_465<?> cs, int playerSlotIndex,
                                                      int bw, int bh, int rightGap, int slotSize) {
            var menu = cs.method_17577();
            var playerInv = getPlayerInventoryFromMenu(menu);
            if (playerInv == null) return null;
            class_1735 target = findSlot(menu, s -> s.field_7871 == playerInv && s.method_34266() == playerSlotIndex);
            if (target == null) return null;

            int left = guiLeft(cs), top = guiTop(cs);
            int slotAbsX = left + target.field_7873, slotAbsY = top + target.field_7872;
            int x = slotAbsX + slotSize + rightGap;
            int y = slotAbsY + ((slotSize - bh) / 2) - 1;
            return new Anchor(x, y);
        }

        private static Anchor anchorAboveContainerIndex(class_465<?> cs, int containerIndex,
                                                        int bw, int bh, int gapY, int slotSize) {
            class_1735 target = nthContainerSlot(cs, containerIndex);
            if (target == null) return null;
            int left = guiLeft(cs), top = guiTop(cs);
            int slotAbsX = left + target.field_7873, slotAbsY = top + target.field_7872;
            int x = (slotAbsX + (slotSize - bw) / 2) - 1;
            int y = slotAbsY - (bh + gapY);
            return new Anchor(x, y);
        }

    private static Anchor anchorRightOfContainerIndex(class_465<?> cs, int containerIndex,
                                                      int bw, int bh, int rightGap, int slotSize) {
        class_1735 target = nthContainerSlot(cs, containerIndex);
        if (target == null) return null;

        int left = guiLeft(cs), top = guiTop(cs);
        int slotAbsX = left + target.field_7873, slotAbsY = top + target.field_7872;

        int x = slotAbsX + slotSize + rightGap;
        int y = slotAbsY + ((slotSize - bh) / 2) - 1;

        return new Anchor(x, y);
    }

        private static class_1735 nthContainerSlot(class_465<?> cs, int containerIndex) {
            var menu = cs.method_17577();
            var playerInv = getPlayerInventoryFromMenu(menu);
            java.util.List<class_1735> containerSlots = new java.util.ArrayList<>();
            for (class_1735 s : menu.field_7761) if (playerInv == null || s.field_7871 != playerInv) containerSlots.add(s);
            if (containerSlots.isEmpty()) return null;
            int idx = Math.min(containerIndex, containerSlots.size() - 1);
            return containerSlots.get(idx);
        }

        private static int guiLeft(class_465<?> cs) {
            try {
                var f = class_465.class.getDeclaredField("leftPos");
                f.setAccessible(true);
                return f.getInt(cs);
            } catch (Throwable ignore) {
                return (cs.field_22789 - guiImageWidth(cs)) / 2;
            }
        }
        private static int guiTop(class_465<?> cs) {
            try {
                var f = class_465.class.getDeclaredField("topPos");
                f.setAccessible(true);
                return f.getInt(cs);
            } catch (Throwable ignore) {
                return (cs.field_22790 - guiImageHeight(cs)) / 2;
            }
        }
        private static int guiImageWidth(class_465<?> cs) {
            try {
                var f = class_465.class.getDeclaredField("imageWidth");
                f.setAccessible(true);
                return f.getInt(cs);
            } catch (Throwable ignore) {
                return 176;
            }
        }
        private static int guiImageHeight(class_465<?> cs) {
            try {
                var f = class_465.class.getDeclaredField("imageHeight");
                f.setAccessible(true);
                return f.getInt(cs);
            } catch (Throwable ignore) {
                return 166;
            }
        }

        private static class_1735 findSlot(class_1703 menu, java.util.function.Predicate<class_1735> pred) {
            for (class_1735 s : menu.field_7761) if (pred.test(s)) return s;
            return null;
        }
        private static net.minecraft.class_1661 getPlayerInventoryFromMenu(class_1703 menu) {
            for (class_1735 s : menu.field_7761) if (s.field_7871 instanceof net.minecraft.class_1661 inv) return inv;
            return null;
        }

    private static void send(QuickStackCommon.Direction dir, QuickStackCommon.Mode mode) {
        var mc = class_310.method_1551();
        if (mc == null || mc.field_1724 == null) return;
        QolNet.sendQuickStack(dir, mode);
        mc.field_1724.method_7353(
                class_2561.method_43470((dir == QuickStackCommon.Direction.PLAYER_TO_CONTAINER ? "Moved to container" : "Moved to inventory")
                        + (mode == QuickStackCommon.Mode.MATCHING_ONLY ? " (matching)" : " (all)")), true);
    }

    private QuickStackButtons() {}
}
