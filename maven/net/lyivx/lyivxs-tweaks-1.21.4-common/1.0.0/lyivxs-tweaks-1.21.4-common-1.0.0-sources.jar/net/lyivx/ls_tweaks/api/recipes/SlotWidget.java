package net.lyivx.ls_tweaks.api.recipes;

import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

/**
 * Slot widget that combines all slot functionality
 */
public class SlotWidget {
    public static class_2960 inputBg = class_2960.method_60655("ls_tweaks", "textures/gui/recipe_viewer/widgets/slots/slot.png");
    public static class_2960 outputBg = class_2960.method_60655("ls_tweaks", "textures/gui/recipe_viewer/widgets/slots/slot_output.png");


    public final SlotRole role;
    public final int x;
    public final int y;
    public final boolean drawBackground;
    public final boolean isOutputStyle;
    public final class_1799 stack;
    public final int recipeJsonIndex;
    public final class_2960 customBackground;
    public final boolean useCustomBackground;
    public final boolean noBackground;     // stable per-slot
    // Dynamic rendering sources (optional)
    private final Supplier<class_1799> stackSupplier;
    private final List<class_1799> stackList;
    private final class_1856 cyclingIngredient;
    private final int cyclingSalt;
    private final int cycleSpeedTicks; // ticks per item when cycling lists/ingredients (default 20)
    private final boolean listCycle;   // whether list sources should cycle (disabled for grid cells)
    private final List<class_1856> ingredientList; // optional per-cell ingredient list for grids

    public SlotWidget(SlotRole role, int x, int y, boolean drawBackground, boolean isOutputStyle,
                      class_1799 stack, int recipeJsonIndex,
                      @Nullable class_2960 customBackground, boolean useCustomBackground, boolean noBackground) {
        this.role = role;
        this.x = x;
        this.y = y;
        this.drawBackground = drawBackground;
        this.isOutputStyle = isOutputStyle;
        this.stack = stack == null ? class_1799.field_8037 : stack.method_7972();
        this.recipeJsonIndex = recipeJsonIndex;
        this.customBackground = customBackground;
        this.useCustomBackground = useCustomBackground;
        this.noBackground = noBackground;
        this.stackSupplier = null;
        this.stackList = null;
        this.cyclingIngredient = null;
        this.cyclingSalt = 0;
        this.cycleSpeedTicks = 20;
        this.listCycle = false;
        this.ingredientList = null;
    }

    public SlotWidget(SlotRole role, int x, int y, boolean drawBackground, boolean isOutputStyle,
                      class_1799 stack, int recipeJsonIndex,
                      @Nullable class_2960 customBackground, boolean useCustomBackground, boolean noBackground,
                      @Nullable Supplier<class_1799> stackSupplier,
                      @Nullable List<class_1799> stackList,
                      @Nullable class_1856 cyclingIngredient,
                      int cyclingSalt,
                      int cycleSpeedTicks,
                      boolean listCycle,
                      @Nullable List<class_1856> ingredientList) {
        this.role = role;
        this.x = x;
        this.y = y;
        this.drawBackground = drawBackground;
        this.isOutputStyle = isOutputStyle;
        this.stack = stack == null ? class_1799.field_8037 : stack.method_7972();
        this.recipeJsonIndex = recipeJsonIndex;
        this.customBackground = customBackground;
        this.useCustomBackground = useCustomBackground;
        this.noBackground = noBackground;
        this.stackSupplier = stackSupplier;
        this.stackList = stackList;
        this.cyclingIngredient = cyclingIngredient;
        this.cyclingSalt = cyclingSalt;
        this.cycleSpeedTicks = Math.max(1, cycleSpeedTicks);
        this.listCycle = listCycle;
        this.ingredientList = ingredientList;
    }

    // Factory methods for common use cases
    public static SlotWidget input(int x, int y, class_1799 stack, int index) {
        return new SlotWidget(SlotRole.INPUT, x, y, true, false, stack, index, inputBg, true, false);
    }
    
    public static SlotWidget inputNoBackground(int x, int y, class_1799 stack, int index) {
        return new SlotWidget(SlotRole.INPUT, x, y, false, false, stack, index, null, false, true);
    }
    
    public static SlotWidget output(int x, int y, class_1799 stack, int index) {
        return new SlotWidget(SlotRole.OUTPUT, x, y, true, true, stack, index, outputBg, true, false);
    }
    
    public static SlotWidget outputNoBackground(int x, int y, class_1799 stack, int index) {
        return new SlotWidget(SlotRole.OUTPUT, x, y, false, true, stack, index, null, false, true);
    }
    
    public static SlotWidget custom(SlotRole role, int x, int y, class_1799 stack, int index, class_2960 background) {
        return new SlotWidget(role, x, y, true, role == SlotRole.OUTPUT, stack, index, background, true, false);
    }
    
    // Ghost slots (for display purposes)
    public static SlotWidget ghost(int x, int y, class_1799 stack, int index) {
        return new SlotWidget(SlotRole.GHOST, x, y, true, false, stack, index, inputBg, true, false);
    }
    
    public static SlotWidget ghostNoBackground(int x, int y, class_1799 stack, int index) {
        return new SlotWidget(SlotRole.GHOST, x, y, false, false, stack, index, null, false, true);
    }
    
    // Catalyst slots (for catalysts, fuel, etc.)
    public static SlotWidget catalyst(int x, int y, class_1799 stack, int index) {
        return new SlotWidget(SlotRole.CATALYST, x, y, true, false, stack, index, inputBg, true, false);
    }
    
    public static SlotWidget catalystNoBackground(int x, int y, class_1799 stack, int index) {
        return new SlotWidget(SlotRole.CATALYST, x, y, false, false, stack, index, null, false, true);
    }
    
    // Fuel slots (specialized for fuel items with automatic fuel selection)
    public static SlotWidget fuel(int x, int y, int index) {
        return new SlotWidget(SlotRole.CATALYST, x, y, true, false, getDefaultFuelItem(null), index, inputBg, true, false);
    }
    
    public static SlotWidget fuelNoBackground(int x, int y, int index) {
        return new SlotWidget(SlotRole.CATALYST, x, y, false, false, getDefaultFuelItem(null), index, null, false, true);
    }
    
    // Helper method to get appropriate fuel item for cooking recipes
    public static class_1799 getDefaultFuelItem(String recipeType) {
        if (recipeType == null) {
            return new class_1799(net.minecraft.class_1802.field_8713);
        }
        
        switch (recipeType.toLowerCase()) {
            case "smelting":
            case "furnace":
            case "blasting":
            case "smoking":
                return new class_1799(net.minecraft.class_1802.field_8713);
            default:
                return new class_1799(net.minecraft.class_1802.field_8713); // fallback
        }
    }

    // Expose size of list-backed source for grid widgets
    public int getStackListSize() {
        return this.stackList == null ? 0 : this.stackList.size();
    }

    /**
     * Renders this slot widget at the given position
     */
    public void render(class_332 g, class_327 font, int baseX, int baseY, int mouseX, int mouseY) {
        int slotX = baseX + this.x;
        int slotY = baseY + this.y;
        class_1799 toRender;
        if (this.stackSupplier != null) {
            try {
                class_1799 supplied = this.stackSupplier.get();
                toRender = supplied == null ? class_1799.field_8037 : supplied;
            } catch (Throwable t) {
                toRender = class_1799.field_8037;
            }
        } else if (this.stackList != null) {
            if (this.listCycle) {
                try {
                    var mc = net.minecraft.class_310.method_1551();
                    long ticks = (mc != null && mc.field_1687 != null) ? mc.field_1687.method_8510() : System.currentTimeMillis() / 50L;
                    int size = this.stackList.size();
                    if (size <= 0) {
                        toRender = class_1799.field_8037;
                    } else {
                        long step = Math.max(1L, this.cycleSpeedTicks);
                        int idx = (int)(((ticks / step) + Math.max(0, this.cyclingSalt)) % size);
                        class_1799 s = this.stackList.get(idx);
                        toRender = (s == null) ? class_1799.field_8037 : s;
                    }
                } catch (Throwable t) {
                    toRender = class_1799.field_8037;
                }
            } else {
                int idx = Math.max(0, this.recipeJsonIndex);
                toRender = (idx < this.stackList.size() && this.stackList.get(idx) != null) ? this.stackList.get(idx) : class_1799.field_8037;
            }
        } else if (this.cyclingIngredient != null) {
            toRender = getCyclingItem(this.cyclingIngredient, this.cyclingSalt, this.cycleSpeedTicks);
        } else {
            toRender = this.stack;
        }
        
        // Draw slot background if not disabled
        if (!this.noBackground) {
            if (this.useCustomBackground && this.customBackground != null) {
                // Determine background size based on slot type
                int bgSize = (this.role == SlotRole.OUTPUT) ? 26 : 18;
                int bgOffset = (this.role == SlotRole.OUTPUT) ? -5 : -1;
                g.method_25290(net.minecraft.class_1921::method_62277, this.customBackground, 
                    slotX + bgOffset, slotY + bgOffset, 0, 0, bgSize, bgSize, bgSize, bgSize);
            } else if (this.drawBackground) {
                class_2960 slotBg = class_2960.method_60656("container/slot");
                g.method_25290(net.minecraft.class_1921::method_62277, slotBg, 
                    slotX - 1, slotY - 1, 0, 0, 18, 18, 18, 18);
            }
        }

        // Draw item (model-aware to preserve tints/dyes)
        g.method_51427(toRender, slotX, slotY);
        g.method_51431(font, toRender, slotX, slotY);
        
        // Add tooltips
        if (mouseX >= slotX && mouseX < slotX + 16 && 
            mouseY >= slotY && mouseY < slotY + 16 && !toRender.method_7960()) {
            List<class_2561> tooltip;
            try {
                // Use the same tooltip method as the item panel for proper item tooltips
                tooltip = net.minecraft.class_437.method_25408(net.minecraft.class_310.method_1551(), toRender);
            } catch (Throwable t) {
                tooltip = new ArrayList<>();
                tooltip.add(toRender.method_7964());
            }
            
            g.method_51434(font, tooltip, mouseX, mouseY);
        }
    }

    // Creates a copy of this slot configured for a specific grid cell position and index,
    // preserving role, backgrounds, suppliers, and cycling settings.
    SlotWidget copyForGridCell(int cellX, int cellY, int index) {
        class_2960 bg = this.customBackground;
        boolean useCustom = this.useCustomBackground;
        boolean drawBg = this.drawBackground;
        if (!useCustom && drawBg && !this.noBackground) {
            bg = (this.isOutputStyle || this.role == SlotRole.OUTPUT)
                    ? outputBg
                    : inputBg;
            useCustom = true;
        }
        return new SlotWidget(
                this.role,
                cellX,
                cellY,
                drawBg,
                this.isOutputStyle,
                this.stack,
                index,
                bg,
                useCustom,
                this.noBackground,
                this.stackSupplier,
                this.stackList,
                this.cyclingIngredient,
                this.cyclingSalt,
                this.cycleSpeedTicks,
                this.listCycle,
                this.ingredientList
        );
    }

    SlotWidget copyForGridCell(int cellX, int cellY, int index, boolean listCycleOverride) {
        class_2960 bg = this.customBackground;
        boolean useCustom = this.useCustomBackground;
        boolean drawBg = this.drawBackground;
        if (!useCustom && drawBg && !this.noBackground) {
            bg = (this.isOutputStyle || this.role == SlotRole.OUTPUT)
                    ? outputBg
                    : inputBg;
            useCustom = true;
        }
        return new SlotWidget(
                this.role,
                cellX,
                cellY,
                drawBg,
                this.isOutputStyle,
                this.stack,
                index,
                bg,
                useCustom,
                this.noBackground,
                this.stackSupplier,
                this.stackList,
                this.cyclingIngredient,
                this.cyclingSalt,
                this.cycleSpeedTicks,
                listCycleOverride,
                this.ingredientList
        );
    }

    private static class_1799 getCyclingItem(class_1856 ingredient, int salt, int speedTicks) {
        try {
            var mc = net.minecraft.class_310.method_1551();
            long t = (mc != null && mc.field_1687 != null) ? mc.field_1687.method_8510() : System.currentTimeMillis() / 50L; // ~20 TPS fallback
            var holders = ingredient.method_8105().toList();
            if (holders.isEmpty()) return class_1799.field_8037;
            long step = Math.max(1L, speedTicks);
            int idx = (int)(((t / step) + Math.max(0, salt)) % holders.size());
            return new class_1799(holders.get(idx).comp_349());
        } catch (Throwable ignored) {}
        return class_1799.field_8037;
    }

    public int getCycleSpeedTicks() { return this.cycleSpeedTicks; }
    public boolean isListCycleEnabled() { return this.listCycle; }
    public @Nullable List<class_1856> getIngredientList() { return this.ingredientList; }
}
