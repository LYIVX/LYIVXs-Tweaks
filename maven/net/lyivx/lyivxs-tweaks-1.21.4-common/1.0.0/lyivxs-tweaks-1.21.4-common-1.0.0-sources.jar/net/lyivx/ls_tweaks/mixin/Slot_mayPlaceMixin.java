package net.lyivx.ls_tweaks.mixin;

import net.lyivx.ls_tweaks.common.feature.slotlock.SlotLockCommon;
import net.lyivx.ls_tweaks.common.util.QuickOpContext;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1735.class)
public abstract class Slot_mayPlaceMixin {
    @Inject(method = "mayPlace", at = @At("HEAD"), cancellable = true)
	private void ls_tweaks$blockLockedPlacement(class_1799 stack, CallbackInfoReturnable<Boolean> cir) {
		class_1735 self = (class_1735)(Object)this;
		if (!(self.field_7871 instanceof class_1661 inv)) return;
		// Only player inventory slots we track (0..35)
		int idx = self.method_34266();
		if (idx < 0 || idx >= 36) return;
        if (inv.field_7546 instanceof class_3222 sp) {
            if (QuickOpContext.isActive()) return; // allow internal quick ops to place
            if (!SlotLockCommon.isLocked(sp, idx)) return;
            boolean allows = SlotLockCommon.allowsItem(sp, idx, stack);
            if (!allows) cir.setReturnValue(false);
        } else {
            // Client side: use client cache to prevent ghost previews from showing as if allowed
            if (QuickOpContext.isActive()) return; // allow internal quick ops to place
            boolean allowsClient = net.lyivx.ls_tweaks.common.feature.slotlock.SlotLockClient.allowsClientPlacement(idx, stack);
            if (!allowsClient) cir.setReturnValue(false);
        }
	}
}
