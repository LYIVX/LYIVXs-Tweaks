package net.lyivx.ls_tweaks.api.recipes;

import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;

/** Simple hoverable tooltip widget over a rectangular area, relative to recipe content origin. */
public class HoverTooltipWidget {
    public final int x, y, width, height;
    public final class_2561 tooltip;

    public HoverTooltipWidget(int x, int y, int width, int height, class_2561 tooltip) {
        this.x = x; this.y = y; this.width = width; this.height = height; this.tooltip = tooltip;
    }

    public void render(class_332 g, class_327 font, int baseX, int baseY, int mouseX, int mouseY) {
        int left = baseX + x;
        int top = baseY + y;
        if (mouseX >= left && mouseX < left + width && mouseY >= top && mouseY < top + height) {
            g.method_51434(font, java.util.List.of(tooltip), mouseX, mouseY);
        }
    }
}


