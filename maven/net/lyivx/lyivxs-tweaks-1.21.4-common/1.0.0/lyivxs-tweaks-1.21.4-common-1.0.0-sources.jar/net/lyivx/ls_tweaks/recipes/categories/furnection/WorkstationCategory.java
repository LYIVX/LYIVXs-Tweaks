package net.lyivx.ls_tweaks.recipes.categories.furnection;

import net.lyivx.ls_furniture.common.recipes.WorkstationRecipe;
import net.lyivx.ls_furniture.registry.ModItems;
import net.lyivx.ls_tweaks.api.recipes.*;
import net.lyivx.ls_tweaks.api.recipes.Widgets.AddGrid.GridBuilder;
import net.lyivx.ls_tweaks.api.recipes.Widgets.AddScroll.ScrollBuilder;
import net.lyivx.ls_tweaks.recipes.util.DisplayUtil;
import net.lyivx.ls_tweaks.recipes.wrappers.WorkstationRecipeHelper;
import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3956;
import net.minecraft.class_5455;
import net.minecraft.class_8786;
import net.minecraft.class_9696;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

/** Simple cooking category base */
public abstract class WorkstationCategory implements RecipeBackedCategory<WorkstationRecipe> {
    private final class_2960 id;
    private final class_2960 icon;
    private final class_3956<WorkstationRecipe> type;

    protected WorkstationCategory(class_2960 id, class_2960 icon, class_3956<WorkstationRecipe> type) {
        this.id = id; 
        this.icon = icon;
        this.type = type;
    }

    @Override public class_2960 id() { return id; }
    @Override public String titleTranslationKey() { return "ls_furniture.category." + id.method_12832(); }
    @Override public class_2960 iconTexture() { return icon; }
    @Override public class_1799 iconItem() { return ModItems.WORKSTATION.get().getDefaultInstance(); }
    @Override public Class<WorkstationRecipe> recipeClass() { return WorkstationRecipe.class; }
    @Override public class_3956<WorkstationRecipe> recipeType() { return type; }
    
    @Override public int sortOrder() {
        return 6;
    }

    @Override
    public RecipeDisplay buildDisplay(WorkstationRecipe recipe) {
        RecipeDisplayBuilder builder = new RecipeDisplayBuilder();

        // Header
        builder.addSlot(Widgets.AddSlot.input(0, 0, recipe.input(), 0).positionTopCenter());
        // Group outputs for same input/inputCount and deduplicate cards (per-frame)
        java.util.List<class_1799> outputs = null;
        if (recipe instanceof WorkstationRecipe wr) {
            outputs = enumerateOutputsFor(wr);
            // Per-tick dedupe by input family + count so usages collapse to one card, but results still show
            try {
                var mc = net.minecraft.class_310.method_1551();
                long tick = (mc != null && mc.field_1687 != null) ? mc.field_1687.method_8510() : 0L;
                if (DEDUPE_TICK != tick) {
                    DEDUPE_SEEN.clear();
                    DEDUPE_TICK = tick;
                }
                class_1799 seedFirst = wr.input().items().findFirst().map(h -> new ItemStack(h.value())).orElse(class_1799.field_8037);
                String inKey = String.valueOf(net.minecraft.class_7923.field_41178.method_10221(seedFirst.method_7909()));
                String groupKey = inKey + "#" + wr.getInputCount();
                if (DEDUPE_SEEN.contains(groupKey)) {
                    return null;
                }
                DEDUPE_SEEN.add(groupKey);
            } catch (Throwable ignored) {
            }

            int columns = 6;
            int rows = Math.max(1, (outputs.size() + columns - 1) / columns);
            int maxVisibleRows = Math.min(rows, 3);
            var grid = Widgets.AddGrid.items(0, 0, columns, rows, Widgets.AddSlot.output(0, 0, outputs, 0)).hideEmptySlots().positionBottomCenter();
            var scroll = Widgets.AddScroll.grid(0, 0, maxVisibleRows, grid).positionBottomCenter();

            int effCols = (grid instanceof Widgets.AddGrid.GridBuilder gb) ? gb.getEffectiveColumns() : columns;
            int effRows = (grid instanceof Widgets.AddGrid.GridBuilder gb2) ? gb2.getEffectiveRows() : rows;

            if (rows <= maxVisibleRows) {
                builder.addSlot(grid);
                builder.contentSize(contentWidth() + effCols * 26, contentHeight() + effRows * 26);
            } else {
                builder.addSlot(scroll);
                builder.contentSize((contentWidth() + effCols * 25) - 2, contentHeight() + Math.min(maxVisibleRows, effRows) * 26);
            }
        } else {
            builder.addSlot(Widgets.AddSlot.output(50, 4, outputs, 0));
            builder.contentSize(contentWidth(), contentHeight());
        }

        return builder.build();
    }

    @Override public int contentWidth() { return 0; }
    @Override public int contentHeight() { return 21; }

    // Per-frame dedupe state for holder-based builds
    private static long DEDUPE_TICK = -1L;
    private static final java.util.Set<String> DEDUPE_SEEN = new java.util.HashSet<>();

    private static class_1799 assembleCookingOutput(WorkstationRecipe recipe) {
        try {
            var mc = net.minecraft.class_310.method_1551();
            var ra = (mc != null && mc.field_1687 != null) ? mc.field_1687.method_30349() : null;
            if (ra == null || recipe == null) return class_1799.field_8037;
            class_1799 first = recipe.input().items().findFirst().map(h -> new ItemStack(h.value())).orElse(class_1799.field_8037);
            var single = new class_9696(first);
            return recipe.assemble(single, ra);
        } catch (Throwable ignored) {}
        return class_1799.field_8037;
    }

    private java.util.List<class_1799> enumerateOutputsFor(WorkstationRecipe seed) {
        java.util.List<class_1799> out = new java.util.ArrayList<>();
        try {
            var mc = net.minecraft.class_310.method_1551();
            Object server = mc != null ? mc.method_1576() : null;
            if (server == null) return out;
            Object rmObj = null;
            try { var m = server.getClass().getMethod("getRecipeManager"); rmObj = m.invoke(server); } catch (Throwable ignored) {}
            if (!(rmObj instanceof net.minecraft.class_1863 rm)) return out;
            var ra = (mc.field_1687 != null) ? mc.field_1687.method_30349() : null;
            if (ra == null) return out;

            class_1799 seedFirst = seed.input().items().findFirst().map(h -> new ItemStack(h.value())).orElse(class_1799.field_8037);
            for (var holder : rm.method_8126()) {
                try {
                    var r = holder.comp_1933();
                    if (!(r instanceof WorkstationRecipe w)) continue;
                    if (w.getInputCount() != seed.getInputCount()) continue;
                    class_1799 otherFirst = w.input().items().findFirst().map(h -> new ItemStack(h.value())).orElse(class_1799.field_8037);
                    boolean same = (!seedFirst.method_7960() && w.input().test(seedFirst)) || (!otherFirst.method_7960() && seed.input().test(otherFirst));
                    if (!same) continue;
                    class_1799 result = assembleCookingOutput(w);
                    if (!result.method_7960()) out.add(result);
                } catch (Throwable ignored) {}
            }
            // Deduplicate by item id while preserving order
            java.util.LinkedHashMap<String, class_1799> uniq = new java.util.LinkedHashMap<>();
            for (class_1799 s : out) {
                String key = String.valueOf(net.minecraft.class_7923.field_41178.method_10221(s.method_7909()));
                uniq.putIfAbsent(key, s);
            }
            out = new java.util.ArrayList<>(uniq.values());
        } catch (Throwable ignored) {}
        return out;
    }
}