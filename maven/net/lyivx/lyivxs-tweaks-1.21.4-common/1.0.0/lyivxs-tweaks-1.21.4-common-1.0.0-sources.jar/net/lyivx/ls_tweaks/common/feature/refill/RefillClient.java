package net.lyivx.ls_tweaks.common.feature.refill;

import dev.architectury.event.events.client.ClientTickEvent;
import dev.architectury.networking.NetworkManager;
import net.lyivx.ls_tweaks.common.config.ConfigProvider;
import net.lyivx.ls_tweaks.common.network.QolNet;
import net.lyivx.ls_tweaks.common.network.QolNet.RefillC2SPayload;
import net.minecraft.class_1799;
import net.minecraft.class_310;

public final class RefillClient {
    private static int lastSelectedSlot = -1;
    private static class_1799 lastSnapshot = class_1799.field_8037;

    public static void register() {
        ClientTickEvent.CLIENT_POST.register(client -> onClientTick());
    }

    private static void onClientTick() {
        var mc = class_310.method_1551();
        if (mc == null || mc.field_1724 == null) return;
        if (!ConfigProvider.refillEnabled()) return;
        // Never run while any GUI screen is open
        if (mc.field_1755 != null) return;
        int slot = mc.field_1724.method_31548().field_7545;
        class_1799 current = mc.field_1724.method_31548().method_7391();

        if (slot != lastSelectedSlot) {
            lastSelectedSlot = slot;
            lastSnapshot = current.method_7972();
            return;
        }
        if (lastSnapshot.method_7960()) {
            lastSnapshot = current.method_7972();
            return;
        }

        boolean becameEmpty = current.method_7960() && !lastSnapshot.method_7960();
        boolean changedTypeOrComponents = !current.method_7960()
                && !class_1799.method_31577(current, lastSnapshot);

        if (becameEmpty || changedTypeOrComponents) {
            var payload = new QolNet.RefillC2SPayload(slot, lastSnapshot.method_7972(), ConfigProvider.refillStrictNbt());
            NetworkManager.sendToServer(payload);

            lastSnapshot = current.method_7972();
        } else {
            lastSnapshot = current.method_7972();
        }
    }
}