package net.lyivx.ls_tweaks.common.feature.quickstack;

import net.lyivx.ls_tweaks.common.config.ConfigProvider;
import net.lyivx.ls_tweaks.common.feature.slotlock.SlotLockCommon;
import net.lyivx.ls_tweaks.common.feature.sort.SortingWhitelist;
import net.lyivx.ls_tweaks.common.util.QuickOpContext;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3222;


public final class QuickStackCommon {

    public enum Direction { PLAYER_TO_CONTAINER, CONTAINER_TO_PLAYER }
    public enum Mode { MATCHING_ONLY, MOVE_ALL }

    /** Entry point from the network payload. */
    public static void handle(class_3222 player, Direction dir, Mode mode) {
        if (player == null) return;
        if (!ConfigProvider.quickStackEnabled()) return;

        class_1703 menu = player.field_7512;
        if (menu == null) return;

        // Only allow when in a whitelisted container screen
        if (!SortingWhitelist.isAllowed(menu, null)) return;

        if (dir == Direction.PLAYER_TO_CONTAINER) {
            move(player, menu, /*fromPlayerInv*/ true, mode);
        } else {
            move(player, menu, /*fromPlayerInv*/ false, mode);
        }
        menu.method_7623();
    }

    private static void move(class_3222 player, class_1703 menu, boolean fromPlayerInv, Mode mode) {
        // side identification not used currently
        Iterable<class_1735> srcSlots  = () -> menu.field_7761.stream().filter(s -> {
            if (fromPlayerInv) {
                if (!(s.field_7871 instanceof class_1661)) return false;
                // skip locked player slots
                return !ConfigProvider.slotLockStopQuickMoves() || !SlotLockCommon.isLocked(player, s.method_34266());
            } else {
                return !(s.field_7871 instanceof class_1661); // container side
            }
        }).iterator();
        Iterable<class_1735> destSlots = () -> menu.field_7761.stream().filter(s -> {
            if (fromPlayerInv) {
                return !(s.field_7871 instanceof class_1661); // container side
            } else {
                if (!(s.field_7871 instanceof class_1661)) return false;
                // when config ON: skip locked entirely; when OFF: we'll validate signature later per-slot
                return !ConfigProvider.slotLockStopQuickMoves() || !SlotLockCommon.isLocked(player, s.method_34266());
            }
        }).iterator();

        for (class_1735 s : srcSlots) {
            class_1799 stack = s.method_7677();
            if (stack.method_7960()) continue;

            if (mode == Mode.MATCHING_ONLY) {
                boolean hasMatch = false;
                for (class_1735 d : destSlots) {
                    class_1799 dst = d.method_7677();
                    if (!dst.method_7960() && class_1799.method_31577(dst, stack)) {
                        hasMatch = true;
                        break;
                    }
                }
                if (!hasMatch) continue;
            }

            // merge into existing stacks first, then empties
            stack = tryMoveStackInto(player, menu, stack, destSlots, /*onlyMerge*/ true);
            if (!stack.method_7960()) {
                stack = tryMoveStackInto(player, menu, stack, destSlots, /*onlyMerge*/ false);
            }
            s.method_7673(stack); // leftover stays in source slot
        }
    }

    /** Moves as much as possible of 'stack' into the destination slots. Returns the leftover. */
    private static class_1799 tryMoveStackInto(class_3222 player, class_1703 menu, class_1799 stack, Iterable<class_1735> destSlots, boolean onlyMerge) {
        if (stack.method_7960()) return class_1799.field_8037;
        class_1799 remaining = stack.method_7972();

        for (class_1735 d : destSlots) {
            if (!d.method_7680(remaining)) continue;
            // If destination is a player slot and it's locked, enforce signature when config is OFF
            if (d.field_7871 instanceof class_1661) {
                int invIdx = d.method_34266();
                if (SlotLockCommon.isLocked(player, invIdx)) {
                    if (ConfigProvider.slotLockStopQuickMoves()) {
                        // config ON: do not place into locked slots at all
                        continue;
                    } else if (!SlotLockCommon.allowsItem(player, invIdx, remaining)) {
                        continue; // locked but non-matching → skip
                    }
                }
            }
            class_1799 existing = d.method_7677();

            if (onlyMerge) {
                if (existing.method_7960()) continue;
                if (!class_1799.method_31577(existing, remaining)) continue;
                int max = Math.min(existing.method_7914(), d.method_7675());
                int canMove = Math.min(remaining.method_7947(), max - existing.method_7947());
                if (canMove > 0) {
                    existing.method_7933(canMove);
                    remaining.method_7934(canMove);
                    d.method_7673(existing);
                    if (remaining.method_7960()) return class_1799.field_8037;
                }
            } else {
                if (!existing.method_7960()) continue;
                int toMove = Math.min(remaining.method_7947(), Math.min(remaining.method_7914(), d.method_7675()));
                if (toMove > 0) {
                    class_1799 place = remaining.method_7972();
                    place.method_7939(toMove);
                    try {
                        QuickOpContext.enter();
                        d.method_7673(place);
                    } finally {
                        QuickOpContext.exit();
                    }
                    remaining.method_7934(toMove);
                    if (remaining.method_7960()) return class_1799.field_8037;
                }
            }
        }
        return remaining;
    }

    private QuickStackCommon() {}
}