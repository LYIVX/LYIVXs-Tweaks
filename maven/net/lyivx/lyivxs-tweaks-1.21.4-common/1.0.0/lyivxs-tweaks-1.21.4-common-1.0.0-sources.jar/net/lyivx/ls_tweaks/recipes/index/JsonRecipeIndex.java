package net.lyivx.ls_tweaks.recipes.index;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.lyivx.ls_tweaks.api.recipes.RecipeDisplay;
import net.lyivx.ls_tweaks.api.recipes.SlotWidget;
import net.lyivx.ls_tweaks.api.recipes.TextureWidget;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/** Minimal JSON-based indexer for common recipe types as a reliable fallback. */
public final class JsonRecipeIndex {
    private static final Map<String, List<JsonRecipe>> BY_RESULT = new HashMap<>();
    private static final Map<String, List<JsonRecipe>> BY_INGREDIENT = new HashMap<>();

    public static void rebuild() { rebuildFrom(class_310.method_1551().method_1478()); }

    public static void rebuildFrom(class_3300 rm) {
        BY_RESULT.clear();
        BY_INGREDIENT.clear();
        try {
            var resources = rm.method_14488("recipes", rl -> rl.method_12832().endsWith(".json"));
            int count = 0;
            for (Map.Entry<class_2960, class_3298> e : resources.entrySet()) {
                try (var in = e.getValue().method_14482()) {
                    JsonElement el = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8));
                    if (!el.isJsonObject()) continue;
                    JsonObject obj = el.getAsJsonObject();
                    String type = getType(obj);
                    if (type == null) continue;
                    JsonRecipe r = parseRecipe(type, obj);
                    if (r == null || r.result.method_7960()) continue;
                    String outKey = keyOf(r.result);
                    BY_RESULT.computeIfAbsent(outKey, k -> new ArrayList<>()).add(r);
                    for (class_1799 inStack : r.inputs) {
                        if (inStack.method_7960()) continue;
                        BY_INGREDIENT.computeIfAbsent(keyOf(inStack), k -> new ArrayList<>()).add(r);
                    }
                    count++;
                } catch (Throwable ignored) {}
            }
            System.out.println("[LS Tweaks][RV] JsonRecipeIndex built recipes=" + count + " resultsKeys=" + BY_RESULT.size());
        } catch (Throwable t) {
            System.out.println("[LS Tweaks][RV] JsonRecipeIndex error: " + t);
        }
    }

    public static List<RecipeDisplay> displaysForResult(class_1799 result) {
        List<RecipeDisplay> out = new ArrayList<>();
        var list = BY_RESULT.getOrDefault(keyOf(result), List.of());
        for (JsonRecipe r : list) out.add(toDisplay(r));
        return out;
    }

    public static List<RecipeDisplay> displaysForUsage(class_1799 ingredient) {
        List<RecipeDisplay> out = new ArrayList<>();
        var list = BY_INGREDIENT.getOrDefault(keyOf(ingredient), List.of());
        for (JsonRecipe r : list) out.add(toDisplay(r));
        return out;
    }

    private static RecipeDisplay toDisplay(JsonRecipe r) {
        List<SlotWidget> slots = new ArrayList<>();
        String t = r.type;
        if (t.endsWith(":crafting_shaped") || t.endsWith(":crafting") || t.endsWith(":crafting_shapeless")) {
            int idx = 0;
            for (int rr = 0; rr < 3; rr++) {
                for (int cc = 0; cc < 3; cc++) {
                    class_1799 st = idx < r.inputs.size() ? r.inputs.get(idx) : class_1799.field_8037;
                    slots.add(SlotWidget.input(cc * 18, rr * 18, st, idx));
                    idx++;
                }
            }
            slots.add(SlotWidget.output(110, 18, r.result, 0));
        } else {
            class_1799 in = r.inputs.isEmpty() ? class_1799.field_8037 : r.inputs.get(0);
            slots.add(SlotWidget.input(0, 18, in, 0));
            slots.add(SlotWidget.output(110, 18, r.result, 0));
        }
        List<TextureWidget> textures = new ArrayList<>();
        TextureWidget arrow = new TextureWidget(78, 20, class_2960.method_60655("ls_tweaks", "textures/gui/widgets/arrows.png"), 0, 0, 24, 17, 24, 17);
        textures.add(arrow);
        return new SimpleDisplay(r.result.method_7964().getString(), slots, textures);
    }

    private static String keyOf(class_1799 s) {
        return s.method_41409().method_40230().map(k -> k.method_29177().toString()).orElse(s.method_7964().getString());
    }

    private static String getType(JsonObject obj) {
        if (obj.has("type")) return obj.get("type").getAsString();
        return null;
    }

    private static JsonRecipe parseRecipe(String type, JsonObject obj) {
        class_1799 result = parseResult(obj.getAsJsonObject("result"));
        List<class_1799> inputs = new ArrayList<>();
        if (type.endsWith(":crafting_shaped") || type.endsWith(":crafting")) {
            if (obj.has("key") && obj.has("pattern")) {
                JsonObject key = obj.getAsJsonObject("key");
                java.util.Map<Character, class_1799> chToItem = new java.util.HashMap<>();
                for (var e : key.entrySet()) {
                    char ch = e.getKey().charAt(0);
                    JsonObject ingr = e.getValue().getAsJsonObject();
                    class_1799 st = parseIngredientFirstItem(ingr);
                    chToItem.put(ch, st);
                }
                var pattern = obj.getAsJsonArray("pattern");
                for (int i = 0; i < 3; i++) {
                    String row = i < pattern.size() ? pattern.get(i).getAsString() : "";
                    for (int j = 0; j < 3; j++) {
                        char ch = j < row.length() ? row.charAt(j) : ' ';
                        inputs.add(ch == ' ' ? class_1799.field_8037 : chToItem.getOrDefault(ch, class_1799.field_8037));
                    }
                }
            }
        } else if (type.endsWith(":crafting_shapeless")) {
            if (obj.has("ingredients")) {
                var arr = obj.getAsJsonArray("ingredients");
                for (int i = 0; i < arr.size(); i++) {
                    class_1799 st = parseIngredientFirstItem(arr.get(i).getAsJsonObject());
                    inputs.add(st);
                }
            }
        } else if (type.endsWith(":smelting") || type.endsWith(":blasting") || type.endsWith(":smoking") || type.endsWith(":stonecutting")) {
            if (obj.has("ingredient")) {
                class_1799 st = parseIngredientFirstItem(obj.getAsJsonObject("ingredient"));
                if (!st.method_7960()) inputs.add(st);
            }
        }
        return new JsonRecipe(type, result, inputs);
    }

    private static class_1799 parseResult(JsonObject res) {
        if (res == null) return class_1799.field_8037;
        String id = res.has("id") ? res.get("id").getAsString() : (res.has("item") ? res.get("item").getAsString() : null);
        if (id == null) return class_1799.field_8037;
        int count = res.has("count") ? res.get("count").getAsInt() : 1;
        class_1792 it = resolveItemById(id);
        return it == null ? class_1799.field_8037 : new class_1799(it, count);
    }

    private static class_1799 parseIngredientFirstItem(JsonObject ingr) {
        if (ingr == null) return class_1799.field_8037;
        // Prefer "item"; ignore tags for now
        if (ingr.has("item")) {
            class_1792 it = resolveItemById(ingr.get("item").getAsString());
            if (it != null) return new class_1799(it);
        }
        return class_1799.field_8037;
    }

    private static class_1792 resolveItemById(String id) {
        try {
            Object registry = net.minecraft.class_7923.field_41178;
            class_2960 rl = class_2960.method_60654(id);
            // Try method get(ResourceLocation)
            try {
                Object val = registry.getClass().getMethod("get", class_2960.class).invoke(registry, rl);
                class_1792 it = extractItem(val);
                if (it != null) return it;
            } catch (Throwable ignored) {}
            // Try getOptional(ResourceLocation)
            try {
                Object val = registry.getClass().getMethod("getOptional", class_2960.class).invoke(registry, rl);
                class_1792 it = extractItem(val);
                if (it != null) return it;
            } catch (Throwable ignored) {}
            // Try getHolder(ResourceLocation)
            try {
                Object val = registry.getClass().getMethod("getHolder", class_2960.class).invoke(registry, rl);
                class_1792 it = extractItem(val);
                if (it != null) return it;
            } catch (Throwable ignored) {}
        } catch (Throwable ignored) {}
        return null;
    }

    private static class_1792 extractItem(Object val) {
        if (val == null) return null;
        try {
            if (val instanceof class_1792) return (class_1792)val;
            if (val instanceof java.util.Optional<?> o) {
                if (o.isEmpty()) return null;
                Object ref = o.get();
                return extractItem(ref);
            }
            // Holder or Holder.Reference
            try {
                Object inner = val.getClass().getMethod("value").invoke(val);
                if (inner instanceof class_1792) return (class_1792)inner;
            } catch (Throwable ignored) {}
        } catch (Throwable ignored) {}
        return null;
    }

    private record JsonRecipe(String type, class_1799 result, List<class_1799> inputs) {}

    private static final class SimpleDisplay implements RecipeDisplay {
        private final String title; private final List<SlotWidget> slots; private final List<TextureWidget> textures;
        private SimpleDisplay(String title, List<SlotWidget> slots, List<TextureWidget> textures) { this.title = title; this.slots = slots; this.textures = textures; }
        public String titleText() { return title; }
        public java.util.List<SlotWidget> slots() { return slots; }
        public java.util.List<TextureWidget> textures() { return textures; }
    }

    private JsonRecipeIndex() {}
}


