package net.lyivx.ls_tweaks.common.network;

import dev.architectury.networking.NetworkManager;
import net.lyivx.ls_tweaks.common.feature.quickstack.QuickStackCommon;
import net.lyivx.ls_tweaks.common.feature.refill.RefillCommon;
import net.lyivx.ls_tweaks.common.feature.sort.SortingCommon;
import net.lyivx.ls_tweaks.common.feature.sort.SortingWhitelistData;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public final class QolNet {
    public static final class_2960 ID_REFILL  = class_2960.method_60655("ls_tweaks", "refill_request");
    public static final class_2960 ID_SORT    = class_2960.method_60655("ls_tweaks", "sort_request");
    public static final class_2960 ID_WL_SYNC = class_2960.method_60655("ls_tweaks", "whitelist_sync");
    public static final class_2960 ID_INV_LAYOUT_SYNC = class_2960.method_60655("ls_tweaks", "inv_layout_sync");
    public static final class_2960 ID_QUICK = class_2960.method_60655("ls_tweaks", "quick_stack");
    public static final class_2960 ID_QUICKMOVE = class_2960.method_60655("ls_tweaks", "quick_move_drag");
    public static final class_2960 ID_SLOTLOCK_TOGGLE = class_2960.method_60655("ls_tweaks", "slotlock_toggle");
    public static final class_2960 ID_SLOTLOCK_SYNC   = class_2960.method_60655("ls_tweaks", "slotlock_sync");

    /* ---------------- Refill C2S ---------------- */

    public record RefillC2SPayload(int hotbarSlot, class_1799 signature, boolean strict)
            implements class_8710 {
        public static final class_9154<RefillC2SPayload> TYPE = new class_9154<>(ID_REFILL);

        public static final class_9139<class_9129, RefillC2SPayload> STREAM_CODEC =
                class_9139.method_56437((buf, p) -> {
                    buf.method_10804(p.hotbarSlot);
                    buf.method_52964(p.strict);
                    class_1799.field_48349.encode(buf, p.signature);
                }, buf -> {
                    int slot = buf.method_10816();
                    boolean strict = buf.readBoolean();
                    class_1799 sig = class_1799.field_48349.decode(buf);
                    return new RefillC2SPayload(slot, sig, strict);
                });

        @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
    }

    /* ---------------- Sort C2S ---------------- */

    public record SortC2SPayload(Target target, Mode mode, boolean mergeBeforeSort, boolean unstackablesLast)
            implements class_8710 {
        public enum Target { PLAYER, CONTAINER }
        public enum Mode   { DEFAULT, ALPHA_ASC, ALPHA_DESC }

        public static final class_9154<SortC2SPayload> TYPE = new class_9154<>(ID_SORT);

        public static final class_9139<class_9129, SortC2SPayload> STREAM_CODEC =
                class_9139.method_56437((buf, p) -> {
                    buf.method_10817(p.target);
                    buf.method_10817(p.mode);
                    buf.method_52964(p.mergeBeforeSort);
                    buf.method_52964(p.unstackablesLast);
                }, buf -> new SortC2SPayload(
                        buf.method_10818(Target.class),
                        buf.method_10818(Mode.class),
                        buf.readBoolean(),
                        buf.readBoolean()
                ));

        @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
    }

    /* ---------------- Whitelist Sync S2C ---------------- */

    public record WhitelistSyncS2CPayload(List<class_2960> menuIds, List<String> screenClasses)
            implements class_8710 {
        public static final class_9154<WhitelistSyncS2CPayload> TYPE = new class_9154<>(ID_WL_SYNC);

        public static final class_9139<class_9129, WhitelistSyncS2CPayload> STREAM_CODEC =
                class_9139.method_56437((buf, p) -> {
                    buf.method_10804(p.menuIds.size());
                    for (var id : p.menuIds) buf.method_10812(id);
                    buf.method_10804(p.screenClasses.size());
                    for (var s : p.screenClasses) buf.method_10814(s);
                }, buf -> {
                    int n = buf.method_10816();
                    List<class_2960> ids = new ArrayList<>(n);
                    for (int i = 0; i < n; i++) ids.add(buf.method_10810());
                    int m = buf.method_10816();
                    List<String> cls = new ArrayList<>(m);
                    for (int i = 0; i < m; i++) cls.add(buf.method_19772());
                    return new WhitelistSyncS2CPayload(ids, cls);
                });

        public static WhitelistSyncS2CPayload from(java.util.Set<String> menuIds, java.util.Set<String> screens) {
            List<class_2960> ids = new ArrayList<>(menuIds.size());
            for (String s : menuIds) ids.add(parseRL(s));
            return new WhitelistSyncS2CPayload(ids, new ArrayList<>(screens));
        }

        @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
    }

    // helper
    private static class_2960 parseRL(String s) {
        int i = s.indexOf(':');
        if (i <= 0) return class_2960.method_60655("minecraft", s);
        return class_2960.method_60655(s.substring(0, i), s.substring(i + 1));
    }

    // ---------- QUICK STACK ----------
    public static final class QuickStackC2SPayload implements class_8710 {
        public static final class_9154<QuickStackC2SPayload> TYPE = new class_9154<>(ID_QUICK);

        public final QuickStackCommon.Direction direction;
        public final QuickStackCommon.Mode mode;

        public QuickStackC2SPayload(QuickStackCommon.Direction direction, QuickStackCommon.Mode mode) {
            this.direction = direction;
            this.mode = mode;
        }

        public static final class_9139<class_9129, QuickStackC2SPayload> CODEC =
                class_9139.method_56437((buf, o) -> {
                            buf.method_10817(o.direction);
                            buf.method_10817(o.mode);
                        },
                        buf -> new QuickStackC2SPayload(
                                buf.method_10818(QuickStackCommon.Direction.class),
                                buf.method_10818(QuickStackCommon.Mode.class)
                        ));

        @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
    }
    // Quick-move (Shift-drag) C2S
    public static final class QuickMoveC2SPayload implements class_8710 {
        public static final class_9154<QuickMoveC2SPayload> TYPE = new class_9154<>(ID_QUICKMOVE);
        public final int slotIndex;
        public QuickMoveC2SPayload(int slotIndex) { this.slotIndex = slotIndex; }
        public static final class_9139<class_9129, QuickMoveC2SPayload> CODEC =
                class_9139.method_56437((buf, p) -> buf.method_10804(p.slotIndex), buf -> new QuickMoveC2SPayload(buf.method_10816()));
        @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
    }


    public static void sendQuickStack(QuickStackCommon.Direction dir, QuickStackCommon.Mode mode) {
        NetworkManager.sendToServer(new QuickStackC2SPayload(dir, mode));
    }


    public record InvLayoutSyncS2CPayload(List<class_2960> verticalMenuIds, List<String> verticalScreenClasses)
            implements class_8710 {
        public static final class_9154<InvLayoutSyncS2CPayload> TYPE = new class_9154<>(ID_INV_LAYOUT_SYNC);

        public static final class_9139<class_9129, InvLayoutSyncS2CPayload> STREAM_CODEC =
                class_9139.method_56437((buf, p) -> {
                    buf.method_10804(p.verticalMenuIds.size());
                    for (var id : p.verticalMenuIds) buf.method_10812(id);
                    buf.method_10804(p.verticalScreenClasses.size());
                    for (var s : p.verticalScreenClasses) buf.method_10814(s);
                }, buf -> {
                    int n = buf.method_10816();
                    List<class_2960> ids = new ArrayList<>(n);
                    for (int i = 0; i < n; i++) ids.add(buf.method_10810());
                    int m = buf.method_10816();
                    List<String> cls = new ArrayList<>(m);
                    for (int i = 0; i < m; i++) cls.add(buf.method_19772());
                    return new InvLayoutSyncS2CPayload(ids, cls);
                });

        public static InvLayoutSyncS2CPayload from(Set<String> verticalIds, Set<String> verticalScreens) {
            List<class_2960> vIds = new ArrayList<>(verticalIds.size());
            for (String s : verticalIds) vIds.add(parseRL(s));
            return new InvLayoutSyncS2CPayload(vIds, new ArrayList<>(verticalScreens));
        }

        @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
    }

    /* ---------------- Slot Lock (C2S toggle / S2C sync) ---------------- */
    public record SlotLockToggleC2SPayload(int playerInvIndex, boolean lock)
            implements class_8710 {
        public static final class_9154<SlotLockToggleC2SPayload> TYPE = new class_9154<>(ID_SLOTLOCK_TOGGLE);
        public static final class_9139<class_9129, SlotLockToggleC2SPayload> STREAM_CODEC =
                class_9139.method_56437((buf, p) -> { buf.method_10804(p.playerInvIndex); buf.method_52964(p.lock); },
                        buf -> new SlotLockToggleC2SPayload(buf.method_10816(), buf.readBoolean()));
        @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
    }

    public record SlotLockSyncS2CPayload(int mask, java.util.List<class_1799> signatures)
            implements class_8710 {
        public static final class_9154<SlotLockSyncS2CPayload> TYPE = new class_9154<>(ID_SLOTLOCK_SYNC);
        public static final class_9139<class_9129, SlotLockSyncS2CPayload> STREAM_CODEC =
                class_9139.method_56437((buf, p) -> {
                    buf.method_10804(p.mask);
                    // fixed 36 entries: write presence + stack if present; avoid encoding EMPTY stacks
                    int n = Math.min(36, p.signatures.size());
                    buf.method_10804(n);
                    for (int i = 0; i < n; i++) {
                        class_1799 st = p.signatures.get(i);
                        boolean present = st != null && !st.method_7960();
                        buf.method_52964(present);
                        if (present) class_1799.field_48349.encode(buf, st);
                    }
                }, buf -> {
                    int m = buf.method_10816();
                    int n = buf.method_10816();
                    java.util.List<class_1799> sigs = new java.util.ArrayList<>(n);
                    for (int i = 0; i < n; i++) {
                        boolean present = buf.readBoolean();
                        if (present) sigs.add(class_1799.field_48349.decode(buf)); else sigs.add(class_1799.field_8037);
                    }
                    return new SlotLockSyncS2CPayload(m, sigs);
                });
        @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
    }

    /* ---------------- Registration ---------------- */

    public static void register() {
        // Refill C2S
        NetworkManager.registerReceiver(
                NetworkManager.Side.C2S,
                RefillC2SPayload.TYPE,
                RefillC2SPayload.STREAM_CODEC,
                (payload, ctx) -> {
                    class_3222 sp = (class_3222) ctx.getPlayer();
                    if (sp != null) RefillCommon.onRefillRequest(sp, payload);
                }
        );

        // Sorting C2S
        NetworkManager.registerReceiver(
                NetworkManager.Side.C2S,
                SortC2SPayload.TYPE,
                SortC2SPayload.STREAM_CODEC,
                (payload, ctx) -> {
                    class_3222 sp = (class_3222) ctx.getPlayer();
                    if (sp != null) SortingCommon.onSortRequest(sp, payload);
                }
        );

        // Whitelist Sync S2C → write into SortingWhitelistData's static sets (client side)
        NetworkManager.registerReceiver(
                NetworkManager.Side.S2C,
                WhitelistSyncS2CPayload.TYPE,
                WhitelistSyncS2CPayload.STREAM_CODEC,
                (payload, ctx) -> {
                    var ids = new LinkedHashSet<String>();
                    for (var rl : payload.menuIds()) ids.add(rl.toString());
                    var screens = new LinkedHashSet<>(payload.screenClasses());
                    // update the client’s current whitelist so UI/logic can read it
                    SortingWhitelistData.setClientWhitelist(ids, screens);
                }
        );

        NetworkManager.registerReceiver(
                NetworkManager.Side.S2C,
                InvLayoutSyncS2CPayload.TYPE,
                InvLayoutSyncS2CPayload.STREAM_CODEC,
                (payload, ctx) -> {
                    var vIds = new java.util.LinkedHashSet<String>();
                    for (var id : payload.verticalMenuIds()) vIds.add(id.toString());
                    var vCls = new java.util.LinkedHashSet<>(payload.verticalScreenClasses());
                    net.lyivx.ls_tweaks.common.feature.sort.InventoryButtonLayoutData.setClientVertical(vIds, vCls);
                }
        );

        NetworkManager.registerReceiver(NetworkManager.Side.C2S, QuickStackC2SPayload.TYPE, QuickStackC2SPayload.CODEC,
                (payload, ctx) -> {
                    if (!(ctx.getPlayer() instanceof class_3222 sp)) return;
                    QuickStackCommon.handle(sp, payload.direction, payload.mode);
        });

        // Quick-move drag C2S
        NetworkManager.registerReceiver(NetworkManager.Side.C2S, QuickMoveC2SPayload.TYPE, QuickMoveC2SPayload.CODEC,
                (payload, ctx) -> {
                    if (!(ctx.getPlayer() instanceof class_3222 sp)) return;
                    net.lyivx.ls_tweaks.common.feature.quickmove.QuickMoveCommon.handle(sp, payload);
                });

        // Slot lock toggle C2S
        NetworkManager.registerReceiver(
                NetworkManager.Side.C2S,
                SlotLockToggleC2SPayload.TYPE,
                SlotLockToggleC2SPayload.STREAM_CODEC,
                (payload, ctx) -> {
                    if (ctx.getPlayer() instanceof class_3222 sp)
                        net.lyivx.ls_tweaks.common.feature.slotlock.SlotLockCommon.handleToggle(sp, payload);
                }
        );
        // Slot lock sync S2C → update client mask (registering also provides the codec for sends)
        NetworkManager.registerReceiver(
                NetworkManager.Side.S2C,
                SlotLockSyncS2CPayload.TYPE,
                SlotLockSyncS2CPayload.STREAM_CODEC,
                (payload, ctx) -> {
                    try {
                        Class<?> c = Class.forName("net.lyivx.ls_tweaks.common.feature.slotlock.SlotLockClient");
                        var m = c.getDeclaredMethod("updateMaskAndSigs", int.class, java.util.List.class);
                        m.invoke(null, payload.mask(), payload.signatures());
                    } catch (Throwable ignored) {
                    }
                }
        );
    }

    private QolNet() {}
}