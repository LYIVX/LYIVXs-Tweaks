package net.lyivx.ls_tweaks.common.feature.refill;

import net.lyivx.ls_tweaks.common.config.ConfigProvider;
import net.lyivx.ls_tweaks.common.debug.QolDebug;
import net.lyivx.ls_tweaks.common.network.QolNet;
import net.lyivx.ls_tweaks.common.util.InvUtils;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_3222;

public final class RefillCommon {
    public static void register() { /* reserved */ }

    public static void onRefillRequest(class_3222 player, QolNet.RefillC2SPayload req) {
        if (!ConfigProvider.refillEnabled()) {
            return;
        }
        int slot = req.hotbarSlot();
        if (slot < 0 || slot > 8) {
            return;
        }

        var inv = player.method_31548();
        class_1799 inSlot = inv.method_5438(slot);

        class_1799 candidate = InvUtils.findMatchingInBackpack(player, req.signature(), req.strict());

        if (candidate.method_7960()) {
            QolDebug.actionbar(player, "Refill: no matching stack found");
            return;
        }
        if (!inSlot.method_7960() && !class_1799.method_31577(inSlot, candidate)) {
            QolDebug.actionbar(player, "Refill: slot occupied");
            return;
        }

        boolean moved = InvUtils.moveIntoHotbarSlot(player, candidate, slot);
        if (moved) {
            QolDebug.actionbar(player, "Refilled " + QolDebug.itemStr(inv.method_5438(slot)));
        } else {
            QolDebug.actionbar(player, "Refill: target full");
        }
    }
}