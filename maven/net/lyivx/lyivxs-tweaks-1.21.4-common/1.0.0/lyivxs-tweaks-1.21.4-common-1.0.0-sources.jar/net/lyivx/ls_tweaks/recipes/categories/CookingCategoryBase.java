package net.lyivx.ls_tweaks.recipes.categories;

import net.lyivx.ls_furniture.common.recipes.WorkstationRecipe;
import net.lyivx.ls_tweaks.api.recipes.RecipeBackedCategory;
import net.lyivx.ls_tweaks.api.recipes.RecipeDisplay;
import net.lyivx.ls_tweaks.api.recipes.RecipeDisplayBuilder;
import net.lyivx.ls_tweaks.api.recipes.Widgets;
import net.lyivx.ls_tweaks.recipes.wrappers.CookingRecipeHelper;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1874;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_5455;
import net.minecraft.class_8786;
import net.minecraft.class_9696;
import net.lyivx.ls_tweaks.recipes.util.DisplayUtil;

/** Simple cooking category base */
public abstract class CookingCategoryBase implements RecipeBackedCategory<class_1874> {
    private final class_2960 id;
    private final class_2960 icon;

    protected CookingCategoryBase(class_2960 id, class_2960 icon) {
        this.id = id; 
        this.icon = icon;
    }

    @Override public class_2960 id() { return id; }
    @Override public String titleTranslationKey() { return "ls_tweaks.category." + id.method_12832(); }
    @Override public class_2960 iconTexture() { return icon; }
    @Override public class_1799 iconItem() { return getIconItem(); }
    
    protected abstract class_1799 getIconItem();
    
    @Override public int sortOrder() {
        String path = id.method_12832();
        if ("smelting".equals(path) || "furnace".equals(path)) return 3;
        if ("blasting".equals(path)) return 4;
        if ("smoking".equals(path)) return 5;
        return Integer.MAX_VALUE;
    }

    @Override
    public RecipeDisplay buildDisplay(class_1874 recipe) {
        return null;
    }

    @Override
    @SuppressWarnings({"rawtypes", "unchecked"})
    public RecipeDisplay buildDisplay(class_8786<? extends class_1860<?>> holder) {
        return buildDisplayWithHolder((class_8786) holder);
    }
    
    public RecipeDisplay buildDisplayWithHolder(class_8786<class_1860<?>> holder) {
        RecipeDisplayBuilder builder = new RecipeDisplayBuilder();

        class_1860<?> recipe = holder.comp_1933();
        class_1856 in = null;
        int cookingTime = 0;
        float experience = 0.0f;
        if (recipe instanceof class_1874 cookingRecipe) {
            // Use helper to get input items reliably
            in = cookingRecipe.method_64720();
            cookingTime = cookingRecipe.method_8167();
            experience = cookingRecipe.method_8171();
        }

        class_1799 out = (recipe instanceof class_1874 cooking) ? assembleCookingOutput(cooking) : DisplayUtil.firstOutput(holder);

        // Set title
        String title = out.method_7960() ? id.toString() : out.method_7964().getString();
        builder.title(title);
        
        // Add input and output slots
        builder.addSlot(Widgets.AddSlot.input(0, 18, in, 0));
        builder.addSlot(Widgets.AddSlot.output(110, 18, out, 0));
        
        // Progress-based arrow
        builder.addTexture(Widgets.AddArrow.Right.progress(78, 20));
        
        // Progress-based flame
        builder.addTexture(Widgets.AddFlame.progress(40, 20));

        // Add labels for cooking time and experience using bounded text widgets
        if (cookingTime > 0) {
            builder.addText(Widgets.AddText.component(40, 35, class_2561.method_43470(cookingTime + "s")).bounds(20, 10));
        }
        if (experience > 0.0f) {
            builder.addText(Widgets.AddText.component(110, 35, class_2561.method_43470(String.format("%.1f XP", experience))).bounds(25, 10).color("lime"));
        }

        // Set content size
        builder.contentSize(150, 66);

        return builder.build();
    }

    @Override public int contentWidth() { return 150; }
    @Override public int contentHeight() { return 66; }

    private static class_1799 assembleCookingOutput(class_1874 recipe) {
        try {
            var mc = net.minecraft.class_310.method_1551();
            var ra = (mc != null && mc.field_1687 != null) ? mc.field_1687.method_30349() : null;
            if (ra == null || recipe == null) return class_1799.field_8037;
            class_1799 first = recipe.method_64720().method_8105().findFirst().map(h -> new class_1799(h.comp_349())).orElse(class_1799.field_8037);
            var single = new net.minecraft.class_9696(first);
            return recipe.method_59998(single, ra);
        } catch (Throwable ignored) {}
        return class_1799.field_8037;
    }
}