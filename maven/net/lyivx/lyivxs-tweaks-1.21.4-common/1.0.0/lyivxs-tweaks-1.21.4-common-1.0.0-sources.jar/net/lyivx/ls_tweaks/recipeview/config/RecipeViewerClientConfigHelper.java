package net.lyivx.ls_tweaks.recipeview.config;

import com.mojang.serialization.Codec;
import net.lyivx.ls_core.client.screens.ModConfigScreen;
import net.lyivx.ls_core.client.screens.widgets.CustomOptionsList;
import net.lyivx.ls_core.common.config.CustomConfigSpec;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_7172;
import java.util.Arrays;

/**
 * Client-only UI bindings for Recipe Viewer config screen.
 */
public final class RecipeViewerClientConfigHelper {
    public static void addConfigOptions(RecipeViewerConfigProvider provider, ModConfigScreen screen, CustomOptionsList list) {
        final CustomConfigSpec spec = RecipeViewerConfigProvider.getConfigSpec();
        if (spec == null) return; // not registered yet

        String modId = provider.getModId();

        // ===== RECIPE VIEWER =====
        list.addTitle(class_2561.method_43471("config.recipe_viewer.title.main"));

        class_7172<Boolean> enabled = class_7172.method_41750(
                "config." + modId + ".enabled",
                class_7172.method_42717(class_2561.method_43471("config." + modId + ".enabled.tooltip")),
                spec.getBoolean("enabled", true),
                v -> spec.setBoolean("enabled", v)
        );
        class_7172<Boolean> showRecipeNames = class_7172.method_41750(
                "config." + modId + ".show_recipe_names",
                class_7172.method_42717(class_2561.method_43471("config." + modId + ".show_recipe_names.tooltip")),
                spec.getBoolean("show_recipe_names", false),
                v -> spec.setBoolean("show_recipe_names", v)
        );
        class_7172<Boolean> showItemPanelBackground = class_7172.method_41750(
                "config." + modId + ".show_item_panel_background",
                class_7172.method_42717(class_2561.method_43471("config." + modId + ".show_item_panel_background.tooltip")),
                spec.getBoolean("show_item_panel_background", false),
                v -> spec.setBoolean("show_item_panel_background", v)
        );
        class_7172<Boolean> showSlotBackgrounds = class_7172.method_41750(
                "config." + modId + ".show_slot_backgrounds",
                class_7172.method_42717(class_2561.method_43471("config." + modId + ".show_slot_backgrounds.tooltip")),
                spec.getBoolean("show_slot_backgrounds", true),
                v -> spec.setBoolean("show_slot_backgrounds", v)
        );
        class_7172<Boolean> tooltipPreferModName = class_7172.method_41750(
                "config." + modId + ".tooltip_prefer_mod_name",
                class_7172.method_42717(class_2561.method_43471("config." + modId + ".tooltip_prefer_mod_name.tooltip")),
                spec.getBoolean("tooltip_prefer_mod_name", true),
                v -> spec.setBoolean("tooltip_prefer_mod_name", v)
        );

        class_7172<RecipeViewerConfigProvider.LayoutPos> buttonsPos = new class_7172<>(
                "config." + modId + ".buttons_pos",
                class_7172.method_42717(class_2561.method_43471("config." + modId + ".buttons_pos.tooltip")),
                (component, value) -> class_2561.method_43471("config." + modId + ".buttons_pos." + value.name().toLowerCase()),
                new class_7172.class_7173<>(
                        Arrays.asList(RecipeViewerConfigProvider.LayoutPos.values()),
                        Codec.STRING.xmap(
                                RecipeViewerConfigProvider.LayoutPos::valueOf,
                                Enum::name
                        )
                ),
                spec.getEnum("buttons_pos", RecipeViewerConfigProvider.LayoutPos.BOTTOM, RecipeViewerConfigProvider.LayoutPos.class),
                (value) -> spec.setEnum("buttons_pos", value)
        );

        class_7172<RecipeViewerConfigProvider.LayoutPos> searchPos = new class_7172<>(
                "config." + modId + ".search_bar_pos",
                class_7172.method_42717(class_2561.method_43471("config." + modId + ".search_bar_pos.tooltip")),
                (component, value) -> class_2561.method_43471("config." + modId + ".search_bar_pos." + value.name().toLowerCase()),
                new class_7172.class_7173<>(
                        Arrays.asList(RecipeViewerConfigProvider.LayoutPos.values()),
                        Codec.STRING.xmap(
                                RecipeViewerConfigProvider.LayoutPos::valueOf,
                                Enum::name
                        )
                ),
                spec.getEnum("search_bar_pos", RecipeViewerConfigProvider.LayoutPos.BOTTOM, RecipeViewerConfigProvider.LayoutPos.class),
                (value) -> spec.setEnum("search_bar_pos", value)
        );

        class_7172<RecipeViewerConfigProvider.FillMode> fillMode = new class_7172<>(
                "config." + modId + ".fill_mode",
                class_7172.method_42717(class_2561.method_43471("config." + modId + ".fill_mode.tooltip")),
                (component, value) -> class_2561.method_43471("config." + modId + ".fill_mode." + value.name().toLowerCase()),
                new class_7172.class_7173<>(
                        Arrays.asList(RecipeViewerConfigProvider.FillMode.values()),
                        Codec.STRING.xmap(
                                RecipeViewerConfigProvider.FillMode::valueOf,
                                Enum::name
                        )
                ),
                spec.getEnum("fill_mode", RecipeViewerConfigProvider.FillMode.CONTAINER_SIZE, RecipeViewerConfigProvider.FillMode.class),
                (value) -> spec.setEnum("fill_mode", value)
        );

        list.addBig(enabled);
        list.addSmall(showRecipeNames, showItemPanelBackground, showSlotBackgrounds, tooltipPreferModName, buttonsPos, searchPos, fillMode);
    }

    public static void openConfigScreen() {
        class_310 mc = class_310.method_1551();
        if (mc == null) return;
        mc.method_1507(new ModConfigScreen(mc.field_1755, mc.field_1690, RecipeViewerConfigProvider.PROVIDER_ID));
    }

    private RecipeViewerClientConfigHelper() {}
}
