package net.lyivx.ls_tweaks.recipes.wrappers;

import net.lyivx.ls_furniture.common.recipes.WorkstationRecipe;
import net.minecraft.class_1799;

/**
 * Helper class to extract input items from cooking recipes reliably
 */
public class WorkstationRecipeHelper {
    
    public static class_1799[] getInputItems(WorkstationRecipe recipe) {
        if (recipe == null) {
            return new class_1799[0];
        }
        
        try {
            var holders = recipe.input().items().toList();
            class_1799[] items = new class_1799[holders.size()];
            for (int i = 0; i < holders.size(); i++) items[i] = new class_1799(holders.get(i).value());
            return items;
        } catch (Exception e) {
            System.out.println("[LS Tweaks][RV] ERROR extracting cooking input: " + e.getMessage());
            return new class_1799[0];
        }
    }
    
    public static class_1799 getFirstInputItem(WorkstationRecipe recipe) {
        class_1799[] items = getInputItems(recipe);
        return items.length > 0 ? items[0] : class_1799.field_8037;
    }
}
