package net.lyivx.ls_tweaks.client.screen;

import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_3917;

/**
 * Simple container menu for the recipe browser screen
 */
public class RecipeBrowserMenu extends class_1703 {
    public static final class_3917<RecipeBrowserMenu> TYPE = new class_3917<RecipeBrowserMenu>(RecipeBrowserMenu::new, null);
    
    public RecipeBrowserMenu(int containerId, class_1661 playerInventory) {
        super(TYPE, containerId);
    }
    
    @Override
    public class_1799 method_7601(class_1657 player, int index) {
        return class_1799.field_8037;
    }
    
    @Override
    public boolean method_7597(class_1657 player) {
        return true; // Always valid for recipe browser
    }
}
