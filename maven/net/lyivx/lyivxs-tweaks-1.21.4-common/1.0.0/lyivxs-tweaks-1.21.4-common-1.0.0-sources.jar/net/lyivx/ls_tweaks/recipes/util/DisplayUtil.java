package net.lyivx.ls_tweaks.recipes.util;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_10352;
import net.minecraft.class_1799;
import net.minecraft.class_1863;
import net.minecraft.class_310;
import net.minecraft.class_8786;

/** Minimal utilities to extract display outputs via RecipeManager display entries. */
public final class DisplayUtil {
    public static class_1799 firstOutput(class_8786<?> holder) {
        List<Object> entries = listEntries(holder);
        for (Object e : entries) {
            class_1799 s = extractFirstResultItem(e);
            if (!s.method_7960()) return s;
        }
        return class_1799.field_8037;
    }

    private static List<Object> listEntries(class_8786<?> holder) {
        List<Object> out = new ArrayList<>();
        try {
            var mc = class_310.method_1551();
            Object server = mc.method_1576();
            if (server == null) return out;
            class_1863 rm = null;
            try {
                var m = server.getClass().getMethod("getRecipeManager");
                Object r = m.invoke(server);
                if (r instanceof class_1863 rmm) rm = rmm;
            } catch (Throwable ignored) {}
            if (rm == null) return out;
            List<Object> list = new ArrayList<>();
            Consumer<Object> cons = list::add;
            try {
                var m = class_1863.class.getMethod("listDisplaysForRecipe", Class.forName("net.minecraft.resources.ResourceKey"), java.util.function.Consumer.class);
                var idM = holder.getClass().getMethod("id");
                Object key = idM.invoke(holder);
                m.invoke(rm, key, cons);
            } catch (Throwable ignored) {}
            out.addAll(list);
        } catch (Throwable ignored) {}
        return out;
    }

    private static class_1799 extractFirstResultItem(Object entry) {
        if (entry == null) return class_1799.field_8037;
        try {
            String clsName = entry.getClass().getName();
            if (clsName.contains("display.RecipeDisplayEntry")) {
                try {
                    Class<?> sdc = Class.forName("net.minecraft.world.item.crafting.display.SlotDisplayContext");
                    var fromLevel = sdc.getMethod("fromLevel", Class.forName("net.minecraft.world.level.Level"));
                    Object ctx = fromLevel.invoke(null, class_310.method_1551().field_1687);
                    var ctxMap = sdc.getMethod("context").invoke(ctx);
                    var resultItems = entry.getClass().getMethod("resultItems", class_10352.class);
                    Object list = resultItems.invoke(entry, ctxMap);
                    if (list instanceof java.util.List<?> ls) {
                        for (Object o : ls) if (o instanceof class_1799 s && !s.method_7960()) return s;
                    }
                } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}
        return class_1799.field_8037;
    }

    private DisplayUtil() {}
}


