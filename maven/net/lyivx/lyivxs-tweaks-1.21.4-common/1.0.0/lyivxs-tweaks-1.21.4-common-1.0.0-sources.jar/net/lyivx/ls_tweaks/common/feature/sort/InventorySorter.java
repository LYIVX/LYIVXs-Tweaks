package net.lyivx.ls_tweaks.common.feature.sort;

import net.lyivx.ls_tweaks.common.network.QolNet;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import java.util.*;
import java.util.Map.Entry;

public final class InventorySorter {

    public static List<class_1799> sort(List<class_1799> input, QolNet.SortC2SPayload.Mode mode, boolean mergeBeforeSort, boolean unstackablesLast) {
        List<class_1799> stacks = new ArrayList<>();
        for (class_1799 st : input) if (!st.method_7960()) stacks.add(st.method_7972());

        if (mergeBeforeSort) stacks = mergeStacks(stacks);

        Comparator<class_1799> cmp = switch (mode) {
            case DEFAULT -> defaultComparator(unstackablesLast);
            case ALPHA_ASC -> alphaComparator(true);
            case ALPHA_DESC -> alphaComparator(false);
        };
        stacks.sort(cmp);

        List<class_1799> out = new ArrayList<>(input.size());
        int i = 0;
        while (i < stacks.size() && i < input.size()) out.add(stacks.get(i++));
        while (out.size() < input.size()) out.add(class_1799.field_8037);
        return out;
    }

    private static Comparator<class_1799> defaultComparator(boolean unstackablesLast) {
        return (a, b) -> {
            int ca = CategoryResolver.categoryPriority(a);
            int cb = CategoryResolver.categoryPriority(b);
            if (ca != cb) return Integer.compare(ca, cb);

            if (unstackablesLast) {
                boolean ua = a.method_7914() == 1;
                boolean ub = b.method_7914() == 1;
                if (ua != ub) return ua ? 1 : -1;
            }

            var ida = class_7923.field_41178.method_10221(a.method_7909());
            var idb = class_7923.field_41178.method_10221(b.method_7909());
            int cmpId = ida.method_12833(idb);
            if (cmpId != 0) return cmpId;

            int ma = a.method_7936(), mb = b.method_7936();
            if (ma > 0 || mb > 0) {
                float ra = ma == 0 ? 0 : (float) a.method_7919() / (float) ma;
                float rb = mb == 0 ? 0 : (float) b.method_7919() / (float) mb;
                int cmpR = Float.compare(ra, rb);
                if (cmpR != 0) return cmpR;
            }

            return Integer.compare(b.method_7947(), a.method_7947());
        };
    }

    private static Comparator<class_1799> alphaComparator(boolean asc) {
        return (a, b) -> {
            String na = nameFor(a);
            String nb = nameFor(b);
            int cmp = na.compareToIgnoreCase(nb);
            if (!asc) cmp = -cmp;
            if (cmp != 0) return cmp;

            // tie: fall back to registry id for stability
            var ida = class_7923.field_41178.method_10221(a.method_7909());
            var idb = class_7923.field_41178.method_10221(b.method_7909());
            cmp = ida.method_12833(idb);
            if (!asc) cmp = -cmp;
            if (cmp != 0) return cmp;

            // final tie: larger stacks first to reduce clutter
            return Integer.compare(b.method_7947(), a.method_7947());
        };
    }

    private static String nameFor(class_1799 st) {
        // Use the hover/display name from server’s language; fallback to registry id if empty.
        String s = st.method_7964().getString();
        if (s == null || s.isBlank()) s = class_7923.field_41178.method_10221(st.method_7909()).toString();
        return s;
    }

    private static List<class_1799> mergeStacks(List<class_1799> in) {
        Map<StackKey, Integer> counts = new LinkedHashMap<>();
        for (class_1799 st : in) counts.merge(StackKey.of(st), st.method_7947(), Integer::sum);
        List<class_1799> out = new ArrayList<>();
        for (var e : counts.entrySet()) {
            var proto = e.getKey().prototype;
            int total = e.getValue();
            int max = proto.method_7914();
            while (total > 0) {
                int n = Math.min(total, max);
                class_1799 part = proto.method_7972();
                part.method_7939(n);
                out.add(part);
                total -= n;
            }
        }
        return out;
    }

    private record StackKey(class_1799 prototype) {
        static StackKey of(class_1799 st) { return new StackKey(st.method_46651(1)); }
        @Override public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof StackKey sk)) return false;
            return class_1799.method_31577(prototype, sk.prototype);
        }
        @Override public int hashCode() {
            return 31 * class_7923.field_41178.method_10221(prototype.method_7909()).hashCode()
                    + prototype.method_57353().hashCode();
        }
    }
}