package net.lyivx.ls_tweaks.common.ui;

import java.util.function.Consumer;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4264;
import net.minecraft.class_7919;

public class IconButton extends class_4264 {
    private final class_2960 icon;
    private final class_2960 iconHover;
    private final Consumer<IconButton> onPressCallback;

    public IconButton(int x, int y, int w, int h,
                      class_2960 icon, class_2960 iconHover,
                      class_2561 tooltip, Consumer<IconButton> onPress) {
        super(x, y, w, h, class_2561.method_43473());
        this.icon = icon;
        this.iconHover = iconHover;
        this.onPressCallback = onPress;
        if (tooltip != null) method_47400(class_7919.method_47407(tooltip));
    }

    @Override
    public void method_25306() {
        if (onPressCallback != null) onPressCallback.accept(this);
    }

    @Override
    protected void method_48579(class_332 g, int mouseX, int mouseY, float partialTick) {
        class_2960 tex = (method_49606() ? iconHover : icon);
        // Draw the 12x10 texture at 1:1 scale
        g.method_25290(class_1921::method_62277, tex, method_46426(), method_46427(), 0, 0, field_22758, field_22759, field_22758, field_22759);
    }

    @Override
    protected void method_47399(net.minecraft.class_6382 n) {
        method_37021(n);
    }
}