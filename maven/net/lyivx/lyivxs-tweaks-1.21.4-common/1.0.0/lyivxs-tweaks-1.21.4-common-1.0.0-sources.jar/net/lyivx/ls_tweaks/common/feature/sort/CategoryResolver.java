package net.lyivx.ls_tweaks.common.feature.sort;

import net.minecraft.class_1738;
import net.minecraft.class_1747;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1766;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1819;
import net.minecraft.class_1829;
import net.minecraft.class_1835;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import net.minecraft.class_9334;
import net.minecraft.world.item.*;

public final class CategoryResolver {
    // Optional helpful tags (if present)
    private static final class_6862<class_1792> LOGS = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("minecraft", "logs"));
    private static final class_6862<class_1792> PLANKS = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("minecraft", "planks"));
    private static final class_6862<class_1792> WOOL = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("minecraft", "wool"));
    private static final class_6862<class_1792> STONE = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("minecraft", "stone_crafting_materials"));
    private static final class_6862<class_1792> ORES = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("minecraft", "ores"));
    private static final class_6862<class_1792> RAILS = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("minecraft", "rails"));

    /**
     * Lower numbers sort earlier.
     * 0 Blocks (logs/planks/stone first), 1 Redstone-ish (rails placeholder), 2 Food, 3 Tools/Weapons/Armor,
     * 4 Misc
     */
    public static int categoryPriority(class_1799 st) {
        class_1792 it = st.method_7909();

        // 0) Blocks first (then sub-buckets by common tags)
        if (it instanceof class_1747 bi) {
            if (st.method_31573(LOGS)) return 0;
            if (st.method_31573(PLANKS)) return 1;
            if (st.method_31573(WOOL)) return 2;
            if (st.method_31573(STONE)) return 3;
            return 4; // other blocks
        }

        // 1) "Redstone-y" odds & ends (placeholder with rails as example)
        if (st.method_31573(RAILS)) return 10;

        // 2) Food
        if (st.method_57826(class_9334.field_50075)) return 20;

        // 3) Tools/Weapons/Armor (damageable or known classes)
        if (st.method_7936() > 0
                || it instanceof class_1829
                || it instanceof class_1766
                || it instanceof class_1753
                || it instanceof class_1764
                || it instanceof class_1835
                || it instanceof class_1819
                || it instanceof class_1738
        ) {
            return 30;
        }

        // 4) Everything else
        return 40;
    }
}