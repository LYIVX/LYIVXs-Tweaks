package net.lyivx.ls_tweaks.recipes.util;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1863;
import net.minecraft.class_310;
import net.minecraft.class_5455;
import net.minecraft.class_634;
import net.minecraft.class_8786;
import net.minecraft.class_9694;
import net.minecraft.class_9696;
import net.minecraft.class_9887;

/** Convenience filters over RecipeManager#getRecipes() for result/ingredient queries. */
public final class RecipeEnumerationResults {
    public static List<class_8786<?>> byResult(class_1799 result) {
        List<class_8786<?>> out = new ArrayList<>();
        if (result == null || result.method_7960()) return out;
        class_1863 mgr = clientRecipeManager();
        if (mgr == null) return out;
        var mc = class_310.method_1551();
        var ra = (mc != null && mc.field_1687 != null) ? mc.field_1687.method_30349() : null;
        for (class_8786<?> rh : mgr.method_8126()) {
            try {
                class_1860<?> r = rh.comp_1933();
                class_1799 produced = class_1799.field_8037;
                if (r instanceof net.minecraft.class_3955 crafting && ra != null) {
                    var input = net.minecraft.class_9694.method_59986(1, 1, java.util.List.of(class_1799.field_8037));
                    produced = crafting.method_8116(input, ra);
                } else if (r instanceof net.minecraft.class_1874 cooking && ra != null) {
                    class_1799 inStack = cooking.method_64720().method_8105().findFirst().map(h -> new class_1799(h.comp_349())).orElse(class_1799.field_8037);
                    var single = new net.minecraft.class_9696(inStack);
                    produced = cooking.method_59998(single, ra);
                } else if (ra != null) {
                    // Generic: try assemble(SingleRecipeInput, Provider) reflectively for custom types (e.g., Workstation)
                    try {
                        java.lang.reflect.Method asm = r.getClass().getMethod("assemble", net.minecraft.class_9696.class, net.minecraft.class_7225.class_7874.class);
                        class_1799 first = firstCandidateFromRecipe(r);
                        if (!first.method_7960()) {
                            var single = new net.minecraft.class_9696(first);
                            Object res = asm.invoke(r, single, ra);
                            if (res instanceof class_1799 s) produced = s;
                        }
                    } catch (Throwable ignored) {}
                } else {
                    produced = DisplayUtil.firstOutput(rh);
                }
                if (!produced.method_7960() && (class_1799.method_31577(produced, result) || produced.method_7909() == result.method_7909())) {
                    out.add(rh);
                }
            } catch (Throwable ignored) {}
        }
        return out;
    }

    private static class_1799 firstCandidateFromRecipe(class_1860<?> r) {
        // Prefer placementInfo().ingredients()
        try {
            var info = r.method_61671();
            if (info != null && info.method_64675() != null) {
                for (var ing : info.method_64675()) {
                    if (ing == null) continue;
                    var opt = ing.method_8105().findFirst();
                    if (opt.isPresent()) return new class_1799(opt.get().comp_349());
                }
            }
        } catch (Throwable ignored) {}
        // Try input() -> Ingredient
        try {
            var m = r.getClass().getMethod("input");
            Object ingObj = m.invoke(r);
            if (ingObj instanceof net.minecraft.class_1856 ing) {
                return ing.method_8105().findFirst().map(h -> new class_1799(h.comp_349())).orElse(class_1799.field_8037);
            }
        } catch (Throwable ignored) {}
        return class_1799.field_8037;
    }

    public static List<class_8786<?>> byIngredient(class_1799 ingredient) {
        List<class_8786<?>> out = new ArrayList<>();
        if (ingredient == null || ingredient.method_7960()) return out;
        class_1863 mgr = clientRecipeManager();
        if (mgr == null) return out;
        for (class_8786<?> rh : mgr.method_8126()) {
            try {
                class_1860<?> r = rh.comp_1933();
                var info = r.method_61671();
                if (info == null || info.method_64675() == null) continue;
                for (class_1856 ing : info.method_64675()) {
                    if (ing != null && ing.method_8093(ingredient)) { out.add(rh); break; }
                }
            } catch (Throwable ignored) {}
        }
        return out;
    }

    private static class_1863 clientRecipeManager() {
        try {
            var mc = class_310.method_1551();
            if (mc == null) return null;
            Object server = mc.method_1576();
            if (server != null) {
                try { var m = server.getClass().getMethod("getRecipeManager"); Object rm = m.invoke(server); if (rm instanceof class_1863 r) return r; } catch (Throwable ignored) {}
            }
            var conn = mc.method_1562();
            if (conn != null) {
                try { var m = conn.getClass().getMethod("getRecipeManager"); Object rm = m.invoke(conn); if (rm instanceof class_1863 r) return r; } catch (Throwable ignored) {}
                for (var m : conn.getClass().getMethods()) {
                    if (m.getParameterCount() == 0 && class_1863.class.isAssignableFrom(m.getReturnType())) {
                        try { Object rm = m.invoke(conn); if (rm instanceof class_1863 r) return r; } catch (Throwable ignored) {}
                    }
                }
            }
        } catch (Throwable ignored) {}
        return null;
    }

    private RecipeEnumerationResults() {}
}


