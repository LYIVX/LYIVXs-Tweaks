package net.lyivx.ls_tweaks.common.feature.slotlock;

import dev.architectury.event.events.common.TickEvent;
import net.lyivx.ls_tweaks.common.config.ConfigProvider;
import net.lyivx.ls_tweaks.common.network.QolNet;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_3222;

/** Server-side slot lock state as a bitmask for 36 player inventory slots (0..35). */
public final class SlotLockCommon {
    private static final java.util.Map<java.util.UUID, Integer> PLAYER_MASK = new java.util.concurrent.ConcurrentHashMap<>();
    private static final java.util.Map<java.util.UUID, ItemSignature[]> PLAYER_SIG = new java.util.concurrent.ConcurrentHashMap<>();

    public static void handleToggle(class_3222 sp, QolNet.SlotLockToggleC2SPayload p) {
        if (sp == null) return;
        int idx = p.playerInvIndex();
        if (idx < 0 || idx >= 36) return;
        int mask = PLAYER_MASK.getOrDefault(sp.method_5667(), 0);
        if (p.lock()) mask |= (1 << idx); else mask &= ~(1 << idx);
        PLAYER_MASK.put(sp.method_5667(), mask);
        // update signature
        ItemSignature[] sig = PLAYER_SIG.computeIfAbsent(sp.method_5667(), k -> new ItemSignature[36]);
        if (p.lock()) {
            var stack = sp.method_31548().method_5438(idx);
            sig[idx] = ItemSignature.from(stack);
        } else {
            sig[idx] = null;
        }
        // sync to client (mask + signatures list)
        java.util.List<net.minecraft.class_1799> list = new java.util.ArrayList<>(36);
        for (int i = 0; i < 36; i++) list.add(sig[i] == null ? null : sig[i].proto());
        dev.architectury.networking.NetworkManager.sendToPlayer(sp, new QolNet.SlotLockSyncS2CPayload(mask, list));
    }

    public static boolean isLocked(class_3222 sp, int invIndex) {
        if (sp == null || invIndex < 0 || invIndex >= 36) return false;
        int mask = PLAYER_MASK.getOrDefault(sp.method_5667(), 0);
        return (mask & (1 << invIndex)) != 0;
    }
    public static boolean allowsItem(class_3222 sp, int invIndex, net.minecraft.class_1799 stack) {
        ItemSignature[] sig = PLAYER_SIG.get(sp.method_5667());
        if (sig == null) return true;
        ItemSignature s = sig[invIndex];
        if (s == null) return true; // no remembered
        return s.matches(stack);
    }

    /** Common registration for server-side validation to enforce locks on any insertion path. */
    public static void register() {
        TickEvent.PLAYER_POST.register(player -> onPlayerTick(player));
    }

    private static void onPlayerTick(net.minecraft.class_1657 player) {
        if (!(player instanceof class_3222 sp)) return;
        int mask = PLAYER_MASK.getOrDefault(sp.method_5667(), 0);
        if (mask == 0) return;
        if (!ConfigProvider.slotLockEnabled()) return;
        class_1661 inv = sp.method_31548();
        ItemSignature[] sig = PLAYER_SIG.get(sp.method_5667());
        if (sig == null) return;
        // For each locked slot, ensure the content matches the signature (if any)
        for (int i = 0; i < 36; i++) {
            if ((mask & (1 << i)) == 0) continue;
            class_1799 inSlot = inv.method_5438(i);
            ItemSignature s = sig[i];
            if (s == null) {
                // If locked but no signature, clear any content out of it
                if (!inSlot.method_7960()) {
                    moveOrDrop(sp, i, inSlot.method_7972());
                    inv.method_5447(i, class_1799.field_8037);
                }
                continue;
            }
            // If slot has item and it doesn't match, relocate it
            if (!inSlot.method_7960() && !class_1799.method_31577(inSlot, s.proto())) {
                moveOrDrop(sp, i, inSlot.method_7972());
                inv.method_5447(i, class_1799.field_8037);
            }
        }
    }

    private static void moveOrDrop(class_3222 sp, int fromIdx, class_1799 stack) {
        class_1661 inv = sp.method_31548();
        // Try merge into existing allowed stacks first
        for (int i = 0; i < 36 && !stack.method_7960(); i++) {
            if (i == fromIdx) continue;
            if (isLocked(sp, i)) continue;
            class_1799 dst = inv.method_5438(i);
            if (!dst.method_7960() && class_1799.method_31577(dst, stack)) {
                int max = Math.min(dst.method_7914(), inv.method_5444());
                int can = Math.min(stack.method_7947(), max - dst.method_7947());
                if (can > 0) {
                    dst.method_7933(can);
                    stack.method_7934(can);
                    inv.method_5447(i, dst);
                }
            }
        }
        // Then place into empty allowed slots
        for (int i = 0; i < 36 && !stack.method_7960(); i++) {
            if (i == fromIdx) continue;
            if (isLocked(sp, i)) continue;
            if (inv.method_5438(i).method_7960()) {
                inv.method_5447(i, stack.method_7972());
                stack.method_7939(0);
            }
        }
        // If still leftovers, drop
        if (!stack.method_7960()) {
            sp.method_7328(stack, false);
        }
    }

    private record ItemSignature(net.minecraft.class_1799 proto) {
        static ItemSignature from(net.minecraft.class_1799 st) {
            if (st == null || st.method_7960()) return null;
            return new ItemSignature(st.method_7972());
        }
        boolean matches(net.minecraft.class_1799 st) {
            if (st == null || st.method_7960()) return false;
            return net.minecraft.class_1799.method_31577(st, proto);
        }
    }

    private SlotLockCommon() {}
}


