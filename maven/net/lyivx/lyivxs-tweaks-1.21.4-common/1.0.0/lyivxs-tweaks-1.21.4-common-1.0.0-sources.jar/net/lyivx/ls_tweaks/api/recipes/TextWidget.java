package net.lyivx.ls_tweaks.api.recipes;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5251;

/**
 * Text widget for displaying text in recipe displays
 */
public class TextWidget {
    public final int x, y;
    public final class_2561 text;
    public final class_5251 color;
    public final boolean centered;
    public final int width, height; // bounds for auto-scaling
    public final boolean autoScale;
    
    public TextWidget(int x, int y, class_2561 text, class_5251 color, boolean centered) {
        this.x = x;
        this.y = y;
        this.text = text;
        this.color = color;
        this.centered = centered;
        this.width = 0;
        this.height = 0;
        this.autoScale = false;
    }
    
    public TextWidget(int x, int y, int width, int height, class_2561 text, class_5251 color, boolean centered) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.text = text;
        this.color = color;
        this.centered = centered;
        this.autoScale = true;
    }
    
    // Factory methods for common use cases
    public static TextWidget translatable(int x, int y, String key) {
        return new TextWidget(x, y, class_2561.method_43471(key), null, false);
    }
    
    public static TextWidget translatable(int x, int y, String key, class_5251 color) {
        return new TextWidget(x, y, class_2561.method_43471(key), color, false);
    }
    
    public static TextWidget translatable(int x, int y, String key, class_124 formatting) {
        return new TextWidget(x, y, class_2561.method_43471(key).method_27692(formatting), null, false);
    }
    
    public static TextWidget literal(int x, int y, String text) {
        return new TextWidget(x, y, class_2561.method_43470(text), null, false);
    }
    
    public static TextWidget literal(int x, int y, String text, class_5251 color) {
        return new TextWidget(x, y, class_2561.method_43470(text), color, false);
    }
    
    public static TextWidget literal(int x, int y, String text, class_124 formatting) {
        return new TextWidget(x, y, class_2561.method_43470(text).method_27692(formatting), null, false);
    }
    
    public static TextWidget centered(int x, int y, String text) {
        return new TextWidget(x, y, class_2561.method_43470(text), null, true);
    }
    
    public static TextWidget centered(int x, int y, String text, class_5251 color) {
        return new TextWidget(x, y, class_2561.method_43470(text), color, true);
    }
    
    public static TextWidget centered(int x, int y, String text, class_124 formatting) {
        return new TextWidget(x, y, class_2561.method_43470(text).method_27692(formatting), null, true);
    }
    
    // Bounded text widgets with auto-scaling
    public static TextWidget bounded(int x, int y, int width, int height, String text) {
        return new TextWidget(x, y, width, height, class_2561.method_43470(text), null, false);
    }
    
    public static TextWidget bounded(int x, int y, int width, int height, String text, class_5251 color) {
        return new TextWidget(x, y, width, height, class_2561.method_43470(text), color, false);
    }
    
    public static TextWidget bounded(int x, int y, int width, int height, String text, class_124 formatting) {
        return new TextWidget(x, y, width, height, class_2561.method_43470(text).method_27692(formatting), null, false);
    }
    
    public static TextWidget boundedCentered(int x, int y, int width, int height, String text) {
        return new TextWidget(x, y, width, height, class_2561.method_43470(text), null, true);
    }
    
    public static TextWidget boundedCentered(int x, int y, int width, int height, String text, class_5251 color) {
        return new TextWidget(x, y, width, height, class_2561.method_43470(text), color, true);
    }
    
    public static TextWidget boundedCentered(int x, int y, int width, int height, String text, class_124 formatting) {
        return new TextWidget(x, y, width, height, class_2561.method_43470(text).method_27692(formatting), null, true);
    }
    
    /**
     * Renders this text widget at the given position
     */
    public void render(class_332 g, class_327 font, int baseX, int baseY) {
        int textX = baseX + this.x;
        int textY = baseY + this.y;
        
        class_2561 text = this.text;
        if (this.color != null) {
            text = text.method_27661().method_27694(style -> style.method_27703(this.color));
        }
        
        if (this.autoScale && this.width > 0 && this.height > 0) {
            // Auto-scale text to fit within bounds
            String textStr = text.getString();
            int textWidth = font.method_1727(textStr);
            int textHeight = font.field_2000;
            
            float scaleX = (float) this.width / textWidth;
            float scaleY = (float) this.height / textHeight;
            float scale = Math.min(scaleX, scaleY);
            
            // Calculate centered position within bounds
            int centerX = this.centered ? textX + this.width / 2 - 1 : textX;
            int centerY = textY;
            
            if (scale < 1.0f) {
                // Scale down the text
                g.method_51448().method_22903();
                g.method_51448().method_46416(centerX, centerY, 0);
                g.method_51448().method_22905(scale, scale, 1.0f);
                
                if (this.centered) {
                    g.method_27534(font, text, 0, 0, 0xFFFFFF);
                } else {
                    g.method_27535(font, text, 0, 0, 0xFFFFFF);
                }
                
                g.method_51448().method_22909();
            } else {
                // Text fits, render normally
                if (this.centered) {
                    g.method_27534(font, text, centerX, centerY, 0xFFFFFF);
                } else {
                    g.method_27535(font, text, textX, textY, 0xFFFFFF);
                }
            }
        } else {
            // Normal rendering without scaling
            if (this.centered) {
                g.method_27534(font, text, textX, textY, 0xFFFFFF);
            } else {
                g.method_27535(font, text, textX, textY, 0xFFFFFF);
            }
        }
    }
}
