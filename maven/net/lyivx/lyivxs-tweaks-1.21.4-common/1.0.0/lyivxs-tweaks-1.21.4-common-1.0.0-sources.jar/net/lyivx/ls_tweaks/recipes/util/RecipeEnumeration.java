package net.lyivx.ls_tweaks.recipes.util;

import net.lyivx.ls_tweaks.api.recipes.RecipeBackedCategory;
import net.lyivx.ls_tweaks.api.recipes.RecipeCategory;
import net.lyivx.ls_tweaks.api.recipes.RecipeDisplay;
import net.minecraft.class_1860;
import net.minecraft.class_1863;
import net.minecraft.class_310;
import net.minecraft.class_3956;
import net.minecraft.class_634;
import net.minecraft.class_8786;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
 

/**
 * Minimal helper to enumerate recipes via RecipeManager when categories specify the RecipeType.
 * Based on NeoForge docs for 1.21.4 recipe access.
 * See: docs "Recipes" and "Built-In Recipe Types".
 */
public final class RecipeEnumeration {
    public static List<RecipeDisplay> buildDisplaysForCategory(RecipeCategory<?> category) {
        if (!(category instanceof RecipeBackedCategory<?> backed)) return List.of();
        class_1863 mgr = clientRecipeManager();
        if (mgr == null) return List.of();

        List<RecipeDisplay> out = new ArrayList<>();
        enumerate(mgr, cast(backed), out);
        return out;
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static <T extends class_1860<?>> void enumerate(class_1863 mgr, RecipeBackedCategory<T> cat, List<RecipeDisplay> out) {
        class_3956<T> type = cat.recipeType();
        if (type == null) return;
        // Iterate all recipes of a type (RecipeManager#recipeMap().byType(type))
        // NeoForge 1.21.4: iterate through manager recipes and filter by type
        try {
            for (class_8786<?> holder : mgr.method_8126()) {
                try {
                    class_1860<?> raw = holder.comp_1933();
                    if (raw == null) continue;
                    if (raw.method_17716() == type && cat.recipeClass().isInstance(raw)) {
                        RecipeDisplay d = ((RecipeCategory)cat).buildDisplay(holder);
                        if (d != null) out.add(d);
                    }
                } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static <T extends class_1860<?>> RecipeBackedCategory<T> cast(RecipeBackedCategory<?> raw) {
        return (RecipeBackedCategory) raw;
    }

    private static class_1863 clientRecipeManager() {
        try {
            var mc = class_310.method_1551();
            if (mc == null) return null;
            // Prefer singleplayer server manager when present
            Object server = mc.method_1576();
            if (server != null) {
                try {
                    var m = server.getClass().getMethod("getRecipeManager");
                    Object rm = m.invoke(server);
                    if (rm instanceof class_1863 r) return r;
                } catch (Throwable ignored) {}
            }
            // Fall back to client connection path (NeoForge keeps a client-side mirror)
            var conn = mc.method_1562();
            if (conn != null) {
                try {
                    var m = conn.getClass().getMethod("getRecipeManager");
                    Object rm = m.invoke(conn);
                    if (rm instanceof class_1863 r) return r;
                } catch (Throwable ignored) {}
                for (var m : conn.getClass().getMethods()) {
                    if (m.getParameterCount() == 0 && class_1863.class.isAssignableFrom(m.getReturnType())) {
                        try { Object rm = m.invoke(conn); if (rm instanceof class_1863 r) return r; } catch (Throwable ignored) {}
                    }
                }
            }
        } catch (Throwable ignored) {}
        return null;
    }

    private RecipeEnumeration() {}
}


