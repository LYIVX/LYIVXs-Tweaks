package net.lyivx.ls_tweaks.recipes.wrappers;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1874;

/**
 * Helper class to extract input items from cooking recipes reliably
 */
public class CookingRecipeHelper {
    
    public static class_1799[] getInputItems(class_1874 recipe) {
        if (recipe == null) {
            return new class_1799[0];
        }
        
        try {
            var holders = recipe.method_64720().method_8105().toList();
            class_1799[] items = new class_1799[holders.size()];
            for (int i = 0; i < holders.size(); i++) items[i] = new class_1799(holders.get(i).comp_349());
            return items;
        } catch (Exception e) {
            System.out.println("[LS Tweaks][RV] ERROR extracting cooking input: " + e.getMessage());
            return new class_1799[0];
        }
    }
    
    public static class_1799 getFirstInputItem(class_1874 recipe) {
        class_1799[] items = getInputItems(recipe);
        return items.length > 0 ? items[0] : class_1799.field_8037;
    }
    
    public static int getCookingTime(class_1874 recipe) {
        if (recipe == null) {
            return 0;
        }
        
        try {
            return recipe.method_8167();
        } catch (Exception e) {
            System.out.println("[LS Tweaks][RV] ERROR extracting cooking time: " + e.getMessage());
            return 0;
        }
    }
    
    public static float getExperience(class_1874 recipe) {
        if (recipe == null) {
            return 0.0f;
        }
        
        try {
            return recipe.method_8171();
        } catch (Exception e) {
            System.out.println("[LS Tweaks][RV] ERROR extracting experience: " + e.getMessage());
            return 0.0f;
        }
    }
}
