package net.lyivx.ls_tweaks.recipes.util;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/** Lightweight helpers for item tags (no dependency on heavy RecipeUtil). */
public final class TagsUtil {
    public static List<class_2960> itemTagIds(class_1799 stack) {
        List<class_2960> out = new ArrayList<>();
        if (stack == null || stack.method_7960()) return out;
        try {
            class_6880<class_1792> holder = stack.method_41409();
            if (holder == null) return out;
            out.addAll(holder.method_40228().map(k -> k.comp_327()).toList());
        } catch (Throwable ignored) {}
        return out;
    }

    public static List<class_1799> itemsInTag(class_2960 tagId) {
        List<class_1799> out = new ArrayList<>();
        if (tagId == null) return out;
        try {
            class_6862<class_1792> key = class_6862.method_40092(class_7924.field_41197, tagId);
            for (class_1792 item : class_7923.field_41178) {
                if (item == null) continue;
                class_6880<class_1792> h = item.method_40131();
                if (h != null && h.method_40220(key)) out.add(new class_1799(item));
            }
        } catch (Throwable ignored) {}
        return out;
    }

    public static List<class_2960> allItemTagIds() {
        Set<class_2960> set = new HashSet<>();
        try {
            for (class_1792 item : class_7923.field_41178) {
                if (item == null) continue;
                class_6880<class_1792> h = item.method_40131();
                if (h == null) continue;
                set.addAll(h.method_40228().map(k -> k.comp_327()).toList());
            }
        } catch (Throwable ignored) {}
        List<class_2960> out = new ArrayList<>(set);
        out.sort(java.util.Comparator.comparing(class_2960::toString));
        return out;
    }

    private TagsUtil() {}
}


