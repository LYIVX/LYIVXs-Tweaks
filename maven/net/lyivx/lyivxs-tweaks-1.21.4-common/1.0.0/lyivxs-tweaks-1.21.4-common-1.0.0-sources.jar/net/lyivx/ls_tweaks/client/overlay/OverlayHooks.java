package net.lyivx.ls_tweaks.client.overlay;

import net.minecraft.class_332;
import net.minecraft.class_465;

/** Central hook methods that loaders call to render and handle the item panel overlay. */
public final class OverlayHooks {
    public static void render(class_465<?> cs, class_332 g) {
        ItemPanelOverlay.render(cs, g);
    }
    public static boolean mouseClick(class_465<?> cs, double x, double y, int button) {
        boolean handled = ItemPanelOverlay.mouseClicked(cs, x, y, button);
        System.out.println("[LS Tweaks][RV] mouseClick handled=" + handled + " btn=" + button + " @" + x + "," + y);
        return handled;
    }
    
    public static boolean keyPressed(class_465<?> cs, int keyCode, int scanCode, int modifiers) {
        return ItemPanelOverlay.keyPressed(cs, keyCode, scanCode, modifiers);
    }
    
    public static boolean charTyped(class_465<?> cs, char codePoint, int modifiers) {
        return ItemPanelOverlay.charTyped(cs, codePoint, modifiers);
    }
    
    private OverlayHooks() {}
}


