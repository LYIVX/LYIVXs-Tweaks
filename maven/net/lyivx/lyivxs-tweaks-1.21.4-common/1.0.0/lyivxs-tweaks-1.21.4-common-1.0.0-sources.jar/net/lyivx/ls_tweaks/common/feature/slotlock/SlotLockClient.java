package net.lyivx.ls_tweaks.common.feature.slotlock;

import dev.architectury.event.events.client.ClientTickEvent;
import dev.architectury.networking.NetworkManager;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.lyivx.ls_tweaks.common.config.ConfigProvider;
import net.lyivx.ls_tweaks.common.network.QolNet;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_481;
import net.minecraft.class_490;

/** Client-only slot locking: Ctrl-Click to lock player inventory slots; overlay renderer; network sync. */
public final class SlotLockClient {
    private static boolean modeEnabled = false;
    private static int lockMask = 0; // bits 0..35
    private static final net.minecraft.class_1799[] SIGNATURES = new net.minecraft.class_1799[36];
    private static boolean prevRight = false;

    public static void register() {
        // Ctrl-Click detection while in player inventory or creative inventory
        ClientTickEvent.CLIENT_POST.register(client -> {
            if (client == null || client.field_1724 == null) return;
            if (!ConfigProvider.slotLockEnabled()) return;
            class_437 scr = client.field_1755;
            if (!(scr instanceof class_465<?> cs)) return;

            long win = client.method_22683().method_4490();
            boolean ctrl = class_3675.method_15987(win, class_3675.field_31950) || class_3675.method_15987(win, class_3675.field_31954);
            boolean mid = org.lwjgl.glfw.GLFW.glfwGetMouseButton(win, org.lwjgl.glfw.GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == org.lwjgl.glfw.GLFW.GLFW_PRESS;
            boolean edge = mid && !prevRight;
            prevRight = mid;
            if (!(ctrl && edge && modeEnabled)) return;

            double mx = client.field_1729.method_1603() * (double)client.method_22683().method_4486() / (double)client.method_22683().method_4489();
            double my = client.field_1729.method_1604() * (double)client.method_22683().method_4502() / (double)client.method_22683().method_4506();
            // Find any player-inventory slot under mouse on this screen
            class_1735 over = getPlayerSlotUnderMouse(cs, (int)mx, (int)my);
            if (over == null) { System.out.println("[LS Tweaks][SlotLock] no player slot under mouse"); return; }
            int invIndex = over.method_34266();
            if (invIndex < 0 || invIndex >= 36) return; // only handle 0..35
            boolean willLock = (lockMask & (1 << invIndex)) == 0;
            // optimistic local update
            if (willLock) {
                lockMask |= (1 << invIndex);
                SIGNATURES[invIndex] = over.method_7677().method_7972();
            } else {
                lockMask &= ~(1 << invIndex);
                SIGNATURES[invIndex] = null;
            }
            // send to server
            NetworkManager.sendToServer(new QolNet.SlotLockToggleC2SPayload(invIndex, willLock));
            System.out.println("[LS Tweaks][SlotLock] toggled invIndex=" + invIndex + " lock=" + willLock);
        });
    }

    public static void updateMask(int mask) { lockMask = mask; }
    public static void updateMaskAndSigs(int mask, java.util.List<net.minecraft.class_1799> sigs) {
        lockMask = mask;
        for (int i = 0; i < SIGNATURES.length; i++) {
            SIGNATURES[i] = (i < sigs.size() && sigs.get(i) != null && !sigs.get(i).method_7960()) ? sigs.get(i) : null;
        }
    }
    public static boolean isLockedPlayerSlot(int inventoryIndex) { return (lockMask & (1 << inventoryIndex)) != 0; }
    public static boolean isModeEnabled() { return modeEnabled; }
    public static void toggleMode() { modeEnabled = !modeEnabled; }

    /** Returns true if a mouse click would place a non-matching item into a locked player slot. */
    public static boolean shouldBlockPlacement(class_465<?> cs, double mx, double my, int button) {
        if (!ConfigProvider.slotLockEnabled()) return false;
        if (button != 0 && button != 1) return false; // left or right click only
        class_1735 over = getPlayerSlotUnderMouse(cs, (int)mx, (int)my);
        if (over == null) return false;
        int idx = over.method_34266();
        if (idx < 0 || idx >= 36) return false;
        if (!isLockedPlayerSlot(idx)) return false;
        var carried = cs.method_17577().method_34255();
        if (carried == null || carried.method_7960()) return false;
        var sig = SIGNATURES[idx];
        if (sig == null) return false;
        return !net.minecraft.class_1799.method_31577(carried, sig);
    }

    public static void drawOverlay(class_465<?> cs, class_332 g) {
        if (!ConfigProvider.slotLockEnabled() || !ConfigProvider.slotLockShowIcons()) return;
        for (class_1735 s : cs.method_17577().field_7761) {
            if (!(s.field_7871 instanceof class_1661)) continue;
            int idx = s.method_34266();
            if (idx < 0 || idx >= 36) continue;
            boolean locked = isLockedPlayerSlot(idx);
            // ghost item when slot is empty but has a signature
            var sig = SIGNATURES[idx];
            if (sig != null && s.method_7677().method_7960()) {
                int gx = getLeft(cs) + s.field_7873;
                int gy = getTop(cs) + s.field_7872;
                renderGhostItem(g, sig, gx, gy);
            }
            // draw lock icon LAST so it appears above everything in the slot
            if (locked) {
                int x = getLeft(cs) + s.field_7873 + 12;
                int y = getTop(cs) + s.field_7872 - 2;
                g.method_25290(class_1921::method_62275, class_2960.method_60655("ls_tweaks", "textures/gui/widgets/lock_overlay.png"), x, y, 0, 0, 6, 6, 6, 6);
            }
        }
    }

    private static void renderGhostItem(class_332 g, net.minecraft.class_1799 stack, int x, int y) {
        g.method_51445(stack, x, y);
        // Dim the item to indicate ghosted state
        g.method_25294(x, y, x + 16, y + 16, 0x66000000);
        // Draw a subtle white outline
        int c = 0x80FFFFFF;
        g.method_25294(x, y, x + 16, y + 1, c);
        g.method_25294(x, y + 15, x + 16, y + 16, c);
        g.method_25294(x, y, x + 1, y + 16, c);
        g.method_25294(x + 15, y, x + 16, y + 16, c);
    }

    /** Client-side helper for mixins: whether a stack is allowed into a locked slot index. */
    public static boolean allowsClientPlacement(int inventoryIndex, net.minecraft.class_1799 stack) {
        if (inventoryIndex < 0 || inventoryIndex >= SIGNATURES.length) return true;
        if (!isLockedPlayerSlot(inventoryIndex)) return true;
        var sig = SIGNATURES[inventoryIndex];
        if (sig == null) return false;
        return net.minecraft.class_1799.method_31577(stack, sig);
    }

    /** Returns true if a number-key hotbar swap into the hovered player slot should be blocked. */
    public static boolean shouldBlockHotbarSwap(class_465<?> cs, double mx, double my, int hotbarIndex) {
        if (!ConfigProvider.slotLockEnabled()) return false;
        if (hotbarIndex < 0 || hotbarIndex > 8) return false;
        class_1735 over = getPlayerSlotUnderMouse(cs, (int)mx, (int)my);
        if (over == null) return false;
        int idx = over.method_34266();
        if (idx < 0 || idx >= 36) return false;
        if (!isLockedPlayerSlot(idx)) return false;
        var sig = SIGNATURES[idx];
        if (sig == null) return true; // locked with no signature: block all
        var src = class_310.method_1551().field_1724 == null ? net.minecraft.class_1799.field_8037 : class_310.method_1551().field_1724.method_31548().method_5438(hotbarIndex);
        if (src.method_7960()) return false; // swapping empty hotbar is fine
        return !net.minecraft.class_1799.method_31577(src, sig);
    }

    // kept intentionally for parity with other client classes; may be referenced reflectively
    private static boolean isPlayerInventory(class_437 s) { return (s instanceof class_490) || (s instanceof class_481); }
    private static class_1735 getPlayerSlotUnderMouse(class_465<?> cs, int mx, int my) {
        try {
            var m = class_465.class.getDeclaredMethod("getSlotUnderMouse");
            m.setAccessible(true);
            Object o = m.invoke(cs);
            if (o instanceof class_1735 s && s.field_7871 instanceof class_1661) return s;
        } catch (Throwable ignored) {
        }
        // Fallback scan with bounds
        for (class_1735 s : cs.method_17577().field_7761) if (s.field_7871 instanceof class_1661 && isPoint(cs, s.field_7873, s.field_7872, 16, 16, mx, my)) return s;
        return null;
    }
    private static boolean isPoint(class_465<?> cs, int x, int y, int w, int h, int px, int py) {
        int left = getLeft(cs), top = getTop(cs);
        int rx = px - left, ry = py - top;
        return rx >= x && ry >= y && rx < x + w && ry < y + h;
        }
    private static int getLeft(class_465<?> cs) {
        try { var f = class_465.class.getDeclaredField("leftPos"); f.setAccessible(true); return f.getInt(cs); } catch (Throwable ignored) { return (cs.field_22789 - 176) / 2; }
    }
    private static int getTop(class_465<?> cs) {
        try { var f = class_465.class.getDeclaredField("topPos"); f.setAccessible(true); return f.getInt(cs); } catch (Throwable ignored) { return (cs.field_22790 - 166) / 2; }
    }

    private SlotLockClient() {}
}


