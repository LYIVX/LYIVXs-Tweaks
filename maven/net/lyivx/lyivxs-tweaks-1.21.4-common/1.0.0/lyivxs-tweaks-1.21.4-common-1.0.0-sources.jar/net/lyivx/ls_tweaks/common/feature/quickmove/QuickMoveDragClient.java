package net.lyivx.ls_tweaks.common.feature.quickmove;

import dev.architectury.event.events.client.ClientTickEvent;
import net.lyivx.ls_tweaks.common.config.ConfigProvider;
import net.lyivx.ls_tweaks.common.feature.slotlock.SlotLockClient;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_465;
import org.lwjgl.glfw.GLFW;
import java.lang.reflect.Field;
import java.util.HashSet;
import java.util.Set;

/** Client handler to upgrade Shift-click to Shift-drag quick-move across items into the open container. */
public final class QuickMoveDragClient {
    private static final Set<Integer> processedThisDrag = new HashSet<>();

    public static void register() {
        
        // Track mouse drag across container screens
        ClientTickEvent.CLIENT_POST.register(client -> {
            if (client == null) return;
            if (!ConfigProvider.quickMoveDragEnabled()) {
                
                processedThisDrag.clear();
                return;
            }

            class_437 scr = client.field_1755;
            if (!(scr instanceof class_465<?> cs)) {
                
                processedThisDrag.clear();
                return;
            }

            long window = client.method_22683().method_4490();
            boolean shiftDown = class_3675.method_15987(window, class_3675.field_31951)
                    || class_3675.method_15987(window, class_3675.field_31955);

            boolean leftDown = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;

            // Avoid interfering with vanilla carry/drag-split: only when not carrying an item
            if (client.field_1724 != null && client.field_1724.field_7512.method_34255() != null && !client.field_1724.field_7512.method_34255().method_7960()) {
                
                processedThisDrag.clear();
                return;
            }

            if (shiftDown && leftDown) {
                // Compute scaled mouse
                double mx = client.field_1729.method_1603() * (double)client.method_22683().method_4486() / (double)client.method_22683().method_4489();
                double my = client.field_1729.method_1604() * (double)client.method_22683().method_4502() / (double)client.method_22683().method_4506();
                class_1735 over = getSlotUnderMouse(cs, (int)mx, (int)my);
                
                boolean isInv = over != null && isPlayerInventorySlot(cs.method_17577(), over);
                boolean isCont = over != null && !isInv; // any non-player slot considered container
                if (over != null && !processedThisDrag.contains(over.field_7874) && over.method_7681() && (isInv || isCont)) {
                    // Respect slot locks for player inventory indices
                    if (isInv && SlotLockClient.isLockedPlayerSlot(over.method_34266())) {
                        processedThisDrag.add(over.field_7874);
                        return;
                    }
                    // Send to server to perform the quick move (networked, like other features)
                    dev.architectury.networking.NetworkManager.sendToServer(new net.lyivx.ls_tweaks.common.network.QolNet.QuickMoveC2SPayload(over.field_7874));
                    processedThisDrag.add(over.field_7874);
                }
            } else {
                
                processedThisDrag.clear();
            }
        });
    }

    private static class_1735 getSlotUnderMouse(class_465<?> cs, int mouseX, int mouseY) {
        for (class_1735 s : cs.method_17577().field_7761) if (isPointInRegion(cs, s.field_7873, s.field_7872, 16, 16, mouseX, mouseY)) return s;
        return null;
    }

    private static boolean isPlayerInventorySlot(class_1703 menu, class_1735 s) {
        return s != null && s.field_7871 instanceof class_1661;
    }

    private static boolean isPointInRegion(class_465<?> cs, int x, int y, int w, int h, int px, int py) {
        int left = getGuiLeft(cs), top = getGuiTop(cs);
        px -= left; py -= top;
        return px >= x && py >= y && px < x + w && py < y + h;
    }

    private static int getGuiLeft(class_465<?> cs) {
        try {
            var f = class_465.class.getDeclaredField("leftPos");
            f.setAccessible(true);
            return f.getInt(cs);
        } catch (Throwable ignored) {
            return (cs.field_22789 - 176) / 2;
        }
    }
    private static int getGuiTop(class_465<?> cs) {
        try {
            var f = class_465.class.getDeclaredField("topPos");
            f.setAccessible(true);
            return f.getInt(cs);
        } catch (Throwable ignored) {
            return (cs.field_22790 - 166) / 2;
        }
    }

    private QuickMoveDragClient() {}
}


