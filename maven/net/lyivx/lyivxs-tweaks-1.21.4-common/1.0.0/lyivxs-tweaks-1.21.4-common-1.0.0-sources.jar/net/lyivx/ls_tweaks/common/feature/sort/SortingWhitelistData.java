package net.lyivx.ls_tweaks.common.feature.sort;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.architectury.event.events.common.LifecycleEvent;
import dev.architectury.event.events.common.PlayerEvent;
import dev.architectury.networking.NetworkManager;
import dev.architectury.registry.ReloadListenerRegistry;
import net.lyivx.ls_tweaks.common.network.QolNet;
import net.lyivx.ls_tweaks.common.network.QolNet.WhitelistSyncS2CPayload;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3264;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import net.minecraft.class_4309;
import net.minecraft.class_7654;
import net.minecraft.server.MinecraftServer;
import java.util.*;

/**
 * Datapack-driven whitelist:
 *   data/<namespace>/ls_tweaks/sorting_whitelist/*.json
 *
 * JSON shape:
 * { "menu_ids": [...], "screen_classes": [...] }
 *
 * Union-merges across all files. Server stores sets and syncs to clients
 * (on join and after datapack reload).
 */
public final class SortingWhitelistData extends class_4309<SortingWhitelistData.Model> {
    public static final String FOLDER = "ls_tweaks/sorting_whitelist";
    private static final class_2960 RELOAD_ID =
            class_2960.method_60655("ls_tweaks", "sorting_whitelist");

    public static final Codec<Model> CODEC = RecordCodecBuilder.create(inst -> inst.group(
            Codec.STRING.listOf().optionalFieldOf("menu_ids", List.of()).forGetter(Model::menu_ids),
            Codec.STRING.listOf().optionalFieldOf("screen_classes", List.of()).forGetter(Model::screen_classes)
    ).apply(inst, Model::new));

    // Server-authoritative (client receives via S2C and writes here too)
    private static volatile Set<String> ALLOWED_MENU_IDS = new LinkedHashSet<>();
    private static volatile Set<String> ALLOWED_SCREENS  = new LinkedHashSet<>();

    private static volatile MinecraftServer SERVER = null;

    public SortingWhitelistData() {
        super(CODEC, class_7654.method_45114(FOLDER));
    }

    @Override
    protected void apply(Map<class_2960, Model> objects, class_3300 rm, class_3695 pf) {
        LinkedHashSet<String> menus   = new LinkedHashSet<>();
        LinkedHashSet<String> screens = new LinkedHashSet<>();

        for (Model m : objects.values()) {
            if (m.menu_ids() != null)       m.menu_ids().forEach(s -> { if (!s.isBlank()) menus.add(s.trim()); });
            if (m.screen_classes() != null) m.screen_classes().forEach(s -> { if (!s.isBlank()) screens.add(s.trim()); });
        }

        ALLOWED_MENU_IDS = menus;
        ALLOWED_SCREENS  = screens;

        // Broadcast to all online players after /reload
        if (SERVER != null) {
            var payload = QolNet.WhitelistSyncS2CPayload.from(ALLOWED_MENU_IDS, ALLOWED_SCREENS);
            for (class_3222 p : SERVER.method_3760().method_14571()) {
                NetworkManager.sendToPlayer(p, payload);
            }
        }
    }

    /** Call during common init. */
    public static void register() {
        ReloadListenerRegistry.register(class_3264.field_14190, new SortingWhitelistData(), RELOAD_ID);

        LifecycleEvent.SERVER_STARTED.register(server -> SERVER = server);
        LifecycleEvent.SERVER_STOPPED.register(server -> SERVER = null);

        PlayerEvent.PLAYER_JOIN.register(player -> {
            if (!(player instanceof class_3222 sp)) return;
            var payload = QolNet.WhitelistSyncS2CPayload.from(ALLOWED_MENU_IDS, ALLOWED_SCREENS);
            NetworkManager.sendToPlayer(sp, payload);
        });
    }

    // ----- Public accessors for other code (client & server) -----
    public static Set<String> allowedMenuIds()      { return ALLOWED_MENU_IDS; }
    public static Set<String> allowedScreenClasses(){ return ALLOWED_SCREENS;  }

    // Called on client when S2C whitelist sync arrives
    public static void setClientWhitelist(Set<String> menuIds, Set<String> screens) {
        ALLOWED_MENU_IDS = new LinkedHashSet<>(menuIds);
        ALLOWED_SCREENS  = new LinkedHashSet<>(screens);
    }

    // ----- JSON model -----
    public static final class Model {
        private final List<String> menu_ids;
        private final List<String> screen_classes;
        public Model(List<String> menu_ids, List<String> screen_classes) {
            this.menu_ids = (menu_ids == null) ? List.of() : new ArrayList<>(menu_ids);
            this.screen_classes = (screen_classes == null) ? List.of() : new ArrayList<>(screen_classes);
        }
        public List<String> menu_ids()       { return menu_ids; }
        public List<String> screen_classes() { return screen_classes; }
    }
}