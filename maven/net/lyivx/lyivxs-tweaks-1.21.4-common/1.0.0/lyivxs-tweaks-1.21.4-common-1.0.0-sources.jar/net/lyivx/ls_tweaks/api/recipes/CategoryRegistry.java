package net.lyivx.ls_tweaks.api.recipes;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_2960;

/** Registry for categories; plugins receive this to register their categories. */
public final class CategoryRegistry {
    private final Map<class_2960, RecipeCategory<?>> idToCategory = new LinkedHashMap<>();

    public <T> void register(RecipeCategory<T> category) {
        idToCategory.put(category.id(), category);
    }

    public RecipeCategory<?> get(class_2960 id) {
        return idToCategory.get(id);
    }

    public Collection<RecipeCategory<?>> all() {
        return Collections.unmodifiableCollection(idToCategory.values());
    }
}


