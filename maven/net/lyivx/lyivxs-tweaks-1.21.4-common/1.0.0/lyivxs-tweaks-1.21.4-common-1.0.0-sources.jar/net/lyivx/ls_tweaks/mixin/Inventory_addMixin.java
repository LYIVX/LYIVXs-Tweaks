package net.lyivx.ls_tweaks.mixin;

import net.lyivx.ls_tweaks.common.feature.slotlock.SlotLockCommon;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1661.class)
public abstract class Inventory_addMixin {
    @Shadow public abstract class_1799 getItem(int slot);
    @Shadow public abstract void setItem(int slot, class_1799 stack);
    @Shadow public abstract int getContainerSize();

    @Inject(method = "add(Lnet/minecraft/world/item/ItemStack;)Z", at = @At("HEAD"), cancellable = true)
    private void ls_tweaks$skipLockedOnAdd(class_1799 stack, CallbackInfoReturnable<Boolean> cir) {
        class_1661 self = (class_1661)(Object)this;
        if (!(self.field_7546 instanceof class_3222 sp)) return;
        if (stack == null || stack.method_7960()) return;

        int original = stack.method_7947();
        int remaining = original;

        // First: try merge into existing stacks that are allowed
        for (int i = 0; i < 36 && remaining > 0; i++) {
            if (SlotLockCommon.isLocked(sp, i) && !SlotLockCommon.allowsItem(sp, i, stack)) continue;
            class_1799 cur = getItem(i);
            if (!cur.method_7960() && class_1799.method_31577(cur, stack)) {
                int max = cur.method_7914();
                int can = Math.min(remaining, max - cur.method_7947());
                if (can > 0) {
                    cur.method_7933(can);
                    remaining -= can;
                    setItem(i, cur);
                }
            }
        }
        // Then: fill empty allowed slots
        for (int i = 0; i < 36 && remaining > 0; i++) {
            if (SlotLockCommon.isLocked(sp, i) && !SlotLockCommon.allowsItem(sp, i, stack)) continue;
            class_1799 cur = getItem(i);
            if (cur.method_7960()) {
                class_1799 place = stack.method_7972();
                place.method_7939(remaining);
                setItem(i, place);
                remaining = 0;
            }
        }

        // Cancel vanilla logic regardless, so it doesn't try placing into locked slots
        stack.method_7939(remaining);
        cir.setReturnValue(remaining != original);
    }
}
