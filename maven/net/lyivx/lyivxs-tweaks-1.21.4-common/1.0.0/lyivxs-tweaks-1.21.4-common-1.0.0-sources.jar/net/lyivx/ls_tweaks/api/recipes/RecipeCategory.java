package net.lyivx.ls_tweaks.api.recipes;

import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.minecraft.class_2960;
import net.minecraft.class_8786;

/** Describes a recipe category (e.g., crafting, smelting). */
public interface RecipeCategory<T> {
    /** Unique id for this category, typically the underlying recipe type id. */
    class_2960 id();

    /** Display name translation key. */
    String titleTranslationKey();

    /** Icon to render for this category tab. */
    class_2960 iconTexture();
    
    /** Item/block icon for this category tab (preferred over texture). */
    default class_1799 iconItem() { return class_1799.field_8037; }

    /**
     * Optional sort order for categories in the browser. Lower values appear first.
     * Defaults to MAX_VALUE (i.e., sorted after explicitly ordered categories).
     */
    default int sortOrder() { return Integer.MAX_VALUE; }

    /** Builds a display from a concrete recipe instance. */
    RecipeDisplay buildDisplay(T recipe);
    
    /** Builds a display from a recipe holder (includes recipe ID). */
    @SuppressWarnings("unchecked")
    default RecipeDisplay buildDisplay(class_8786<? extends class_1860<?>> holder) {
        return buildDisplay((T) holder.comp_1933());
    }

    /** Optional: width/height of the content area for layout. */
    default int contentWidth() { return 150; }
    default int contentHeight() { return 66; }
}


