package net.lyivx.ls_tweaks.common.config;

import com.mojang.serialization.Codec;
import net.lyivx.ls_core.client.screens.ModConfigScreen;
import net.lyivx.ls_core.client.screens.widgets.CustomOptionsList;
import net.lyivx.ls_core.common.config.CustomConfigSpec;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_7172;
import java.util.Arrays;

/**
 * Client-only UI bindings for LYIVX's Core config screen.
 * Minimal booleans bound directly to the live CustomConfigSpec.
 */
public final class ClientConfigHelper {
    public static void addConfigOptions(ConfigProvider provider, ModConfigScreen screen, CustomOptionsList list) {
        final CustomConfigSpec spec = ConfigProvider.getConfigSpec();
        if (spec == null) return; // not registered yet

        String modId = provider.getModId();

        // ===== SORTING =====
        list.addTitle(class_2561.method_43471("config.ls_tweaks.title.sorting"));

        class_7172<Boolean> sortingEnabled = class_7172.method_41750(
                "config." + modId + ".sorting_enabled",
                class_7172.method_42717(class_2561.method_43471("config." + modId + ".sorting_enabled.tooltip")),
                spec.getBoolean("sorting_enabled", true),
                v -> spec.setBoolean("sorting_enabled", v)
        );
        class_7172<Boolean> showSortingBtns = class_7172.method_41750(
                "config." + modId + ".ui_show_sorting_buttons",
                class_7172.method_42717(class_2561.method_43471("config." + modId + ".ui_show_sorting_buttons.tooltip")),
                spec.getBoolean("ui_show_sorting_buttons", true),
                v -> spec.setBoolean("ui_show_sorting_buttons", v)
        );
        class_7172<Boolean> sortingMinimizedDisplay = class_7172.method_41750(
                "config." + modId + ".sorting_minimizedDisplay",
                class_7172.method_42717(class_2561.method_43471("config." + modId + ".sorting_minimizedDisplay.tooltip")),
                spec.getBoolean("sorting_minimizedDisplay", false),
                v -> spec.setBoolean("sorting_minimizedDisplay", v)
        );

        class_7172<ConfigProvider.SortMode> defaultSortMode = new class_7172<>(
                "config." + modId + ".sorting_default_sort_mode",
                class_7172.method_42717(class_2561.method_43471("config." + modId + ".sorting_default_sort_mode.tooltip")),
                (component, value) -> class_2561.method_43471("config." + modId + ".sorting_default_sort_mode." + value.name().toLowerCase()),
                new class_7172.class_7173<>(
                        Arrays.asList(ConfigProvider.SortMode.values()),
                        Codec.STRING.xmap(
                                ConfigProvider.SortMode::safeValueOf,
                                Enum::name
                        )
                ),
                spec.getEnum("sorting_default_sort_mode", ConfigProvider.SortMode.CATEGORY, ConfigProvider.SortMode.class),
                (value) -> spec.setEnum("sorting_default_sort_mode", value)
        );

        // Only the 'Enable' is big
        list.addBig(sortingEnabled);
        list.addSmall(showSortingBtns, sortingMinimizedDisplay, defaultSortMode);

        // ===== REFILL =====
        list.addTitle(class_2561.method_43471("config.ls_tweaks.title.refill"));

        class_7172<Boolean> refillEnabled = class_7172.method_41750(
                "config." + modId + ".refill_enabled",
                class_7172.method_42717(class_2561.method_43471("config." + modId + ".refill_enabled.tooltip")),
                spec.getBoolean("refill_enabled", true),
                v -> spec.setBoolean("refill_enabled", v)
        );
        class_7172<Boolean> refillStrictNbt = class_7172.method_41750(
                "config." + modId + ".refill_strictNbt",
                class_7172.method_42717(class_2561.method_43471("config." + modId + ".refill_strictNbt.tooltip")),
                spec.getBoolean("refill_strictNbt", true),
                v -> spec.setBoolean("refill_strictNbt", v)
        );
        

        list.addBig(refillEnabled);
        list.addSmall(refillStrictNbt);

        // ===== QUICK STACK =====
        list.addTitle(class_2561.method_43471("config.ls_tweaks.title.quickstack"));

        class_7172<Boolean> quickStackEnabled = class_7172.method_41750(
                "config." + modId + ".quickstack_enabled",
                class_7172.method_42717(class_2561.method_43471("config." + modId + ".quickstack_enabled.tooltip")),
                spec.getBoolean("quickstack_enabled", true),
                v -> spec.setBoolean("quickstack_enabled", v)
        );
        class_7172<Boolean> quickStackAllowCont = class_7172.method_41750(
                "config." + modId + ".quickstack_allowContainerActions",
                class_7172.method_42717(class_2561.method_43471("config." + modId + ".quickstack_allowContainerActions.tooltip")),
                spec.getBoolean("quickstack_allowContainerActions", true),
                v -> spec.setBoolean("quickstack_allowContainerActions", v)
        );
        class_7172<Boolean> showQuickStackBtns = class_7172.method_41750(
                "config." + modId + ".ui_show_quickstack_buttons",
                class_7172.method_42717(class_2561.method_43471("config." + modId + ".ui_show_quickstack_buttons.tooltip")),
                spec.getBoolean("ui_show_quickstack_buttons", true),
                v -> spec.setBoolean("ui_show_quickstack_buttons", v)
        );

        list.addBig(quickStackEnabled);
        list.addSmall(quickStackAllowCont, showQuickStackBtns);

        // ===== UI (Shared) =====
        list.addTitle(class_2561.method_43471("config.ls_tweaks.title.ui"));

        // Shift-Drag Quick-Move
        class_7172<Boolean> quickMoveDrag = class_7172.method_41750(
                "config." + modId + ".quickmove_drag_enabled",
                class_7172.method_42717(class_2561.method_43471("config." + modId + ".quickmove_drag_enabled.tooltip")),
                spec.getBoolean("quickmove_drag_enabled", true),
                v -> spec.setBoolean("quickmove_drag_enabled", v)
        );
        list.addSmall(quickMoveDrag);

        // Slot Locking
        class_7172<Boolean> slotLockEnabled = class_7172.method_41750(
                "config." + modId + ".slotlock_enabled",
                class_7172.method_42717(class_2561.method_43471("config." + modId + ".slotlock_enabled.tooltip")),
                spec.getBoolean("slotlock_enabled", true),
                v -> spec.setBoolean("slotlock_enabled", v)
        );
        class_7172<Boolean> slotLockShowIcons = class_7172.method_41750(
                "config." + modId + ".slotlock_showIcons",
                class_7172.method_42717(class_2561.method_43471("config." + modId + ".slotlock_showIcons.tooltip")),
                spec.getBoolean("slotlock_showIcons", true),
                v -> spec.setBoolean("slotlock_showIcons", v)
        );
        class_7172<Boolean> slotLockStopQuickMoves = class_7172.method_41750(
                "config." + modId + ".slotlock_stopQuickMoves",
                class_7172.method_42717(class_2561.method_43471("config." + modId + ".slotlock_stopQuickMoves.tooltip")),
                spec.getBoolean("slotlock_stopQuickMoves", false),
                v -> spec.setBoolean("slotlock_stopQuickMoves", v)
        );
        list.addBig(slotLockEnabled);
        list.addSmall(slotLockShowIcons, slotLockStopQuickMoves);

        // ===== KEYBINDS (header only; binding is in Controls) =====
        list.addTitle(class_2561.method_43471("config.ls_tweaks.title.keybinds"));

        // Inline keybind capture buttons
        KeybindButton sortKeyBtn = new KeybindButton(
                0, 0, 180, 20,
                "config.ls_tweaks.keybind_sort_key",
                net.lyivx.ls_tweaks.common.keybinds.SortKeybind.SORT_KEY,
                spec,
                "keybind_sort_key"
        );
        KeybindButton openConfigBtn = new KeybindButton(
                0, 0, 180, 20,
                "config.ls_tweaks.keybind_open_config_key",
                net.lyivx.ls_tweaks.common.keybinds.ConfigKeybind.OPEN_CONFIG,
                spec,
                "keybind_open_config_key"
        );

        list.addSmall(sortKeyBtn, openConfigBtn);
    }

    // (helpers removed; logic moved into KeybindButton)

    public static void openConfigScreen() {
        class_310 mc = class_310.method_1551();
        if (mc == null) return;
        mc.method_1507(new ModConfigScreen(mc.field_1755, mc.field_1690, ConfigProvider.PROVIDER_ID));
    }
    private ClientConfigHelper() {}
}
