package net.lyivx.ls_tweaks.mixin;

import net.lyivx.ls_tweaks.client.overlay.OverlayHooks;
import net.minecraft.class_309;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_309.class)
public class KeyboardHandlerMixin {

    @Inject(method = "charTyped", at = @At("HEAD"), cancellable = true)
    private void ls_tweaks$onCharTyped(long window, int codePoint, int modifiers, CallbackInfo ci) {
        class_437 scr = class_310.method_1551().field_1755;
        if (scr instanceof class_465<?> cs) {
            if (OverlayHooks.charTyped(cs, (char) codePoint, modifiers)) {
                ci.cancel();
            }
        }
    }
}


