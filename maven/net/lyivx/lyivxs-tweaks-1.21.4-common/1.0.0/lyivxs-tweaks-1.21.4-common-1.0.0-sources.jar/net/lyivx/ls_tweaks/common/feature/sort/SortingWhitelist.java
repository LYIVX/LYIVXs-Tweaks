package net.lyivx.ls_tweaks.common.feature.sort;

import net.minecraft.class_1703;
import net.minecraft.class_2960;
import net.minecraft.class_437;
import net.minecraft.class_7923;

public final class SortingWhitelist {
    public static boolean isAllowed(class_1703 menu, class_437 screen) {
        // menu id whitelist
        if (menu != null) {
            class_2960 id = class_7923.field_41187.method_10221(menu.method_17358());
            if (id != null && SortingWhitelistData.allowedMenuIds().contains(id.toString())) return true;
        }
        // OR screen class whitelist
        if (screen != null) {
            String cn = screen.getClass().getName();
            if (SortingWhitelistData.allowedScreenClasses().contains(screen.getClass().getName())) return true;
        }
        return false;
    }
    private SortingWhitelist() {}
}