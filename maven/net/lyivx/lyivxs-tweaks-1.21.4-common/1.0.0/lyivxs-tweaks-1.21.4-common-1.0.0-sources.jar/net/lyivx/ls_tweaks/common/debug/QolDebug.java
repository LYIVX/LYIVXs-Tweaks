package net.lyivx.ls_tweaks.common.debug;

import net.lyivx.ls_tweaks.LYIVXs_tweaks;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/** Toggleable debug logger + helpers. */
public final class QolDebug {
    public static boolean ENABLED = true; // flip off when done

    public static void log(String msg) {
        if (!ENABLED) return;
        // Console print
        System.out.println("[QOL DEBUG] " + msg);
        // Mod logger (shows with log level)
        LYIVXs_tweaks.LOGGER.info("[QOL DEBUG] {}", msg);
    }

    public static String itemStr(class_1799 st) {
        if (st == null || st.method_7960()) return "EMPTY";
        class_2960 id = class_7923.field_41178.method_10221(st.method_7909());
        return id + " x" + st.method_7947();
    }

    public static void actionbar(net.minecraft.class_3222 sp, String msg) {
        if (!ENABLED) return;
        sp.method_7353(class_2561.method_43470(msg), true);
    }
}