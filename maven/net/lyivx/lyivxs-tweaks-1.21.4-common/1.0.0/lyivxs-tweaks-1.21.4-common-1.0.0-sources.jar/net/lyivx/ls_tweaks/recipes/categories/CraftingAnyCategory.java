package net.lyivx.ls_tweaks.recipes.categories;

import java.util.List;
import java.util.Optional;
import net.lyivx.ls_tweaks.api.recipes.RecipeBackedCategory;
import net.lyivx.ls_tweaks.api.recipes.RecipeDisplay;
import net.lyivx.ls_tweaks.api.recipes.RecipeDisplayBuilder;
import net.lyivx.ls_tweaks.api.recipes.Widgets;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1869;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3955;
import net.minecraft.class_3956;
import net.minecraft.class_5455;
import net.minecraft.class_9887;

/** Simple crafting category for 1.21.4 */
public final class CraftingAnyCategory implements RecipeBackedCategory<class_3955> {
    private static final class_2960 ID = class_2960.method_60655("minecraft", "crafting");
    private static final class_2960 ICON = class_2960.method_60655("minecraft", "textures/item/crafting_table.png");
    private static final class_2960 SHAPELESS = class_2960.method_60655("ls_tweaks", "textures/gui/recipe_viewer/widgets/shapeless.png");

    @Override public class_2960 id() { return ID; }
    @Override public String titleTranslationKey() { return "ls_tweaks.category.crafting"; }
    @Override public class_2960 iconTexture() { return ICON; }
    @Override public class_1799 iconItem() { return new class_1799(class_1802.field_8465); }
    @Override public int sortOrder() { return 0; }

    @Override public Class<class_3955> recipeClass() { return class_3955.class; }
    @Override public class_3956<class_3955> recipeType() { return class_3956.field_17545; }

    @Override
    public RecipeDisplay buildDisplay(class_3955 recipe) {
        boolean isShapeless = !(recipe instanceof class_1869);

        class_1799 out = assembleResult(recipe);
        RecipeDisplayBuilder builder = new RecipeDisplayBuilder();

        // Title
        String title = out.method_7960() ? "Crafting" : out.method_7964().getString();
        if (isShapeless) title += " (Shapeless)";
        builder.title(title);

        // Build flattened 3x3 ingredients for per-cell cycling
        java.util.List<class_1856> ings = new java.util.ArrayList<>(9);
        for (int i = 0; i < 9; i++) ings.add(null);
        if (recipe instanceof class_1869 shaped) {
            int w = shaped.method_8150();
            int h = shaped.method_8158();
            var list = shaped.method_61693(); // List<Optional<Ingredient>>
            int p = 0;
            for (int ry = 0; ry < h; ry++) {
                for (int rx = 0; rx < w; rx++) {
                    int gx = rx + (3 - w) / 2;
                    int gy = ry + (3 - h) / 2;
                    class_1856 ing = null;
                    if (list != null && p < list.size()) {
                        var opt = list.get(p);
                        if (opt != null && opt.isPresent()) ing = opt.get();
                    }
                    if (ing != null) {
                        int ci = gy * 3 + gx;
                        if (ci >= 0 && ci < 9) ings.set(ci, ing);
                    }
                    p++;
                }
            }
        } else {
            java.util.List<class_1856> ingredients = java.util.List.of();
            try {
                var info = recipe.method_61671();
                if (info != null && info.method_64675() != null) ingredients = info.method_64675();
            } catch (Throwable ignored) {}
            for (int i = 0; i < Math.min(9, ingredients.size()); i++) ings.set(i, ingredients.get(i));
        }
        // Use GridSlotWidget per-cell ingredient cycling; inherits speed from template slot
        // Provide ingredients via the template slot; grid/scroll will consume from it
        builder.addSlot(Widgets.AddGrid.items(0, 0, 3, 3, Widgets.AddSlot.input(0, 0, ings, 0)).positionMiddleLeft());

        // Output + arrow
        builder.addSlot(Widgets.AddSlot.output(0, 0, out, 0).positionMiddleRight());
        builder.addTexture(Widgets.AddArrow.Right.progress(57, 20));

        // Shapeless marker
        if (isShapeless) {
            builder.addTexture(Widgets.AddTexture.staticTexture(55, 35, SHAPELESS, 0, 0, 18, 18, 18, 18));
            builder.addHover(Widgets.AddHover.literal(55, 35, 18, 18, "Shapeless"));
        }

        builder.contentSize(108, (3 * 18));
        return builder.build();
    }

    private static class_1799 assembleResult(class_3955 recipe) {
        try {
            var mc = net.minecraft.class_310.method_1551();
            var ra = (mc != null && mc.field_1687 != null) ? mc.field_1687.method_30349() : null;
            if (ra == null) return class_1799.field_8037;
            net.minecraft.class_9694 input = net.minecraft.class_9694.method_59986(1, 1, java.util.List.of(class_1799.field_8037));
            return recipe.method_8116(input, ra);
        } catch (Throwable ignored) {}
        return class_1799.field_8037;
    }

    @Override public int contentWidth() { return 128; }
    @Override public int contentHeight() { return 3 * 18; }
}