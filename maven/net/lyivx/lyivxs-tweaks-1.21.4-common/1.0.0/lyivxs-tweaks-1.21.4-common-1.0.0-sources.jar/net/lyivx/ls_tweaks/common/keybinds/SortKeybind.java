package net.lyivx.ls_tweaks.common.keybinds;

import dev.architectury.registry.client.keymappings.KeyMappingRegistry;
import net.lyivx.ls_tweaks.common.config.ConfigProvider;
import net.minecraft.class_304;

public class SortKeybind {
    public static class_304 SORT_KEY;

    public static void register() {
        int keyCode = ConfigProvider.keybindSortKey();
        SORT_KEY = new class_304("key.ls_tweaks.sort_inventory", keyCode, "category.ls_tweaks");
        KeyMappingRegistry.register(SORT_KEY);
    }
}
