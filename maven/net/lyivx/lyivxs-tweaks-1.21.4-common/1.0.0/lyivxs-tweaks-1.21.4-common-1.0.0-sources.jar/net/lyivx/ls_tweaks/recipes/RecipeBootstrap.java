package net.lyivx.ls_tweaks.recipes;

import net.lyivx.ls_furniture.common.recipes.WorkstationRecipe;
import net.lyivx.ls_furniture.registry.ModItems;
import net.lyivx.ls_furniture.registry.ModRecipes;
import net.lyivx.ls_tweaks.api.recipes.RecipeDisplay;
import net.lyivx.ls_tweaks.recipes.categories.CookingCategoryBase;
import net.lyivx.ls_tweaks.recipes.categories.CraftingAnyCategory;
import net.lyivx.ls_tweaks.recipes.categories.TagsCategory;
import net.lyivx.ls_tweaks.recipes.categories.furnection.WorkstationCategory;
import net.minecraft.class_1802;
import net.minecraft.class_1874;
import net.minecraft.class_2960;
import net.minecraft.class_3956;

/** Registers built-in categories. */
public final class RecipeBootstrap {
    public static void registerBuiltins() {
        // 1.21.4 crafting: register unified category bound to the crafting recipe type
        RecipeBrowser.CATEGORIES.register(new CraftingAnyCategory());
        // Basic furnace-like categories bound to their recipe types
        RecipeBrowser.CATEGORIES.register(new CookingCategoryBase(net.minecraft.class_2960.method_60655("minecraft", "smelting"), net.minecraft.class_2960.method_60655("minecraft", "textures/item/furnace.png")){
            @Override
            public RecipeDisplay buildDisplay(class_1874 recipe) {
                return null;
            }

            @Override protected net.minecraft.class_1799 getIconItem() { return new net.minecraft.class_1799(class_1802.field_8732); }
            @Override public Class<class_1874> recipeClass() { return class_1874.class; }
            @Override public class_3956<class_1874> recipeType() { return (class_3956) class_3956.field_17546; }
        });
        RecipeBrowser.CATEGORIES.register(new CookingCategoryBase(net.minecraft.class_2960.method_60655("minecraft", "blasting"), net.minecraft.class_2960.method_60655("minecraft", "textures/item/blast_furnace.png")){
            @Override protected net.minecraft.class_1799 getIconItem() { return new net.minecraft.class_1799(class_1802.field_16306); }
            @Override public Class<class_1874> recipeClass() { return class_1874.class; }
            @Override public class_3956<class_1874> recipeType() { return (class_3956) class_3956.field_17547; }
        });
        RecipeBrowser.CATEGORIES.register(new CookingCategoryBase(net.minecraft.class_2960.method_60655("minecraft", "smoking"), net.minecraft.class_2960.method_60655("minecraft", "textures/item/smoker.png")){
            @Override protected net.minecraft.class_1799 getIconItem() { return new net.minecraft.class_1799(class_1802.field_16309); }
            @Override public Class<class_1874> recipeClass() { return class_1874.class; }
            @Override public class_3956<class_1874> recipeType() { return (class_3956) class_3956.field_17548; }
        });
        // Tags category (usages only)
        RecipeBrowser.CATEGORIES.register(new TagsCategory());


        RecipeBrowser.CATEGORIES.register(new WorkstationCategory(class_2960.method_60655("ls_furniture", "workstation"), net.minecraft.class_2960.method_60655("ls_furniture", "textures/item/furnace.png"), ModRecipes.WORKSTATION_RECIPE.get()) {

            @Override
            public class_3956<WorkstationRecipe> recipeType() {
                return ModRecipes.WORKSTATION_RECIPE.get();
            }
        });
    }
    private RecipeBootstrap() {}
}


