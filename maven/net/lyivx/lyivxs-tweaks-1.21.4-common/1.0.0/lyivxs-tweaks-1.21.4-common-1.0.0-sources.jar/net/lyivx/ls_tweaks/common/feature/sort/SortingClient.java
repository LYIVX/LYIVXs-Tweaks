package net.lyivx.ls_tweaks.common.feature.sort;

import dev.architectury.event.events.client.ClientTickEvent;
import dev.architectury.networking.NetworkManager;
import net.lyivx.ls_tweaks.common.config.ConfigProvider;
import net.lyivx.ls_tweaks.common.config.ConfigProvider.SortMode;
import net.lyivx.ls_tweaks.common.debug.QolDebug;
import net.lyivx.ls_tweaks.common.network.QolNet;
import net.minecraft.class_1703;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_481;
import net.minecraft.class_490;
import net.minecraft.class_7923;
import org.lwjgl.glfw.GLFW;

import static net.lyivx.ls_tweaks.common.keybinds.SortKeybind.SORT_KEY;

public final class SortingClient {
    private static boolean guiWasDown = false; // edge-detect while a GUI is open

    /** Call from client init. */
    public static void register() {

        ClientTickEvent.CLIENT_POST.register(client -> {
            if (client == null) return;

            // Only function when some GUI is open (inventory or container)
            class_437 scr = client.field_1755;
            if (scr == null) { guiWasDown = false; return; }

            boolean isPlayerInvScreen = (scr instanceof class_490) || (scr instanceof class_481);
            boolean isContainerScreen = scr instanceof class_465<?>;

            if (!isPlayerInvScreen && !isContainerScreen) {
                guiWasDown = false;
                return; // chat/pause/others
            }

            // Poll current bound key while GUI is up (KeyMapping.consumeClick() won’t fire here)
            int keyCode = SORT_KEY.method_1429().method_1444();
            if (keyCode == class_3675.field_16237.method_1444()) { guiWasDown = false; return; }
            long window = class_310.method_1551().method_22683().method_4490();
            boolean down = class_3675.method_15987(window, keyCode);

            // Edge detection
            if (!down || guiWasDown) { guiWasDown = down; return; }
            guiWasDown = true;

            // ---- key pressed (with a GUI open) ----
            try {
                debug("==== Sort key pressed (GUI) ====");
                if (client.field_1724 == null) { debug("Abort: player is null"); return; }

                // Config flags
                boolean enabled = ConfigProvider.sortingEnabled();
                boolean allowContainers = ConfigProvider.sortingAllowContainerSorting();
                boolean merge = ConfigProvider.sortingMergeBeforeSort();
                boolean unstackLast = ConfigProvider.sortingUnstackablesLast();
                debug("Config -> enabled=" + enabled + ", allowContainers=" + allowContainers +
                        ", mergeBefore=" + merge + ", unstackLast=" + unstackLast);
                if (!enabled) { toast(client, "Sorting disabled."); debug("Abort: sorting disabled"); return; }

                // Shift state
                boolean shiftDown = class_3675.method_15987(window, GLFW.GLFW_KEY_LEFT_SHIFT)
                        || class_3675.method_15987(window, GLFW.GLFW_KEY_RIGHT_SHIFT);
                debug("ShiftDown=" + shiftDown);

                // R (no shift) ALWAYS sorts PLAYER inventory (works on both inventory and container screens)
                if (!shiftDown) {
                    debug("Action: sort PLAYER inventory (R)");
                    NetworkManager.sendToServer(new QolNet.SortC2SPayload(
                            QolNet.SortC2SPayload.Target.PLAYER,
                            resolveDefaultSortMode(),
                            merge, unstackLast
                    ));
                    toast(client, "Sorting: Inventory");
                    debug("Sent SortC2S (PLAYER).");
                    return;
                }

                // Shift+R sorts the CONTAINER — only if a real container screen is open
                if (!isContainerScreen) {
                    debug("Abort: Shift+R but no container screen (inventory or other GUI)");
                    toast(client, "No container to sort.");
                    return;
                }

                class_1703 menu = client.field_1724.field_7512;
                if (menu == null) {
                    debug("Abort: container screen but menu is null");
                    toast(client, "No container to sort.");
                    return;
                }

                // Safe: only read MenuType id for actual container screens
                class_2960 menuId = class_7923.field_41187.method_10221(menu.method_17358());
                debug("Container screen=" + scr.getClass().getName() + "  MenuType=" + (menuId == null ? "<null>" : menuId));

                if (!allowContainers) {
                    debug("Abort: allowContainerSorting=false");
                    toast(client, "Container sorting disabled.");
                    return;
                }

                boolean wl = SortingWhitelist.isAllowed(menu, (class_465<?>) scr);
                debug("Whitelist=" + wl);
                if (!wl) {
                    debug("Abort: container not whitelisted");
                    toast(client, "Container not whitelisted.");
                    return;
                }

                debug("Action: sort CONTAINER (Shift+R)");
                NetworkManager.sendToServer(new QolNet.SortC2SPayload(
                        QolNet.SortC2SPayload.Target.CONTAINER,
                        resolveDefaultSortMode(),
                        merge, unstackLast
                ));
                toast(client, "Sorting: Container");
                debug("Sent SortC2S (CONTAINER).");

            } catch (Throwable t) {
                debug("Exception during sort key handling: " + t);
            } finally {
                debug("==== Sort key handling done ====");
            }
        });
    }

    private static QolNet.SortC2SPayload.Mode resolveDefaultSortMode() {
        var cfg = ConfigProvider.defaultSortMode();
        // Map config sort choice to network mode
        return switch (cfg) {
            case CATEGORY -> QolNet.SortC2SPayload.Mode.DEFAULT;
            case A_TO_Z -> QolNet.SortC2SPayload.Mode.ALPHA_ASC;
            case Z_TO_A -> QolNet.SortC2SPayload.Mode.ALPHA_DESC;
        };
    }

    private static void toast(class_310 mc, String msg) {
        if (mc.field_1724 != null) mc.field_1724.method_7353(class_2561.method_43470("[LS Tweaks] " + msg), true);
    }

    private static void debug(String s) {
        try { QolDebug.log("[SortingClient] " + s); }
        catch (Throwable ignored) { System.out.println("[LS Tweaks][SortingClient] " + s); }
    }

    private SortingClient() {}
}