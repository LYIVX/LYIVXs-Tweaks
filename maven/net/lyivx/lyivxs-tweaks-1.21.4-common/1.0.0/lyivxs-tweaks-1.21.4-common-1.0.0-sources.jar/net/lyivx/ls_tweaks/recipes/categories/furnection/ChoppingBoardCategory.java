package net.lyivx.ls_tweaks.recipes.categories.furnection;

import net.lyivx.ls_furniture.common.recipes.ChoppingBoardRecipe;
import net.lyivx.ls_furniture.registry.ModItems;
import net.lyivx.ls_tweaks.api.recipes.RecipeBackedCategory;
import net.lyivx.ls_tweaks.api.recipes.RecipeDisplay;
import net.lyivx.ls_tweaks.api.recipes.RecipeDisplayBuilder;
import net.lyivx.ls_tweaks.api.recipes.Widgets;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3956;

import static net.lyivx.ls_furniture.LYIVXsFurnitureMod.MOD_ID;

public class ChoppingBoardCategory implements RecipeBackedCategory<ChoppingBoardRecipe> {
    private final class_3956<ChoppingBoardRecipe> type;

    protected ChoppingBoardCategory(class_3956<ChoppingBoardRecipe> type) {
        this.type = type;
    }

    @Override public class_2960 id() { return class_2960.method_60655(MOD_ID, "chopping_board"); }
    @Override public String titleTranslationKey() { return "ls_furniture.category." + id().method_12832(); }

    @Override
    public class_2960 iconTexture() {
        return null;
    }

    @Override public class_1799 iconItem() { return ModItems.CHOPPING_BOARD.get().getDefaultInstance(); }
    @Override public Class<ChoppingBoardRecipe> recipeClass() { return ChoppingBoardRecipe.class; }
    @Override public class_3956<ChoppingBoardRecipe> recipeType() { return type; }
    @Override public int sortOrder() {
        return 7;
    }
    @Override
    public RecipeDisplay buildDisplay(ChoppingBoardRecipe recipe) {
        RecipeDisplayBuilder builder = new RecipeDisplayBuilder();


        class_1799 outputs = recipe.getResultItem();

        builder.addSlot(Widgets.AddSlot.input(0, 2, recipe.input(), 20, 0).noBackground().positionTopCenter());
        builder.addSlot(Widgets.AddSlot.input(0, 2, ModItems.KNIFE.get().getDefaultInstance(), 0).noBackground().positionTopLeft());
        builder.addIcon(Widgets.AddIcon.of(0,0, recipe.input(), 0));
        if (recipe.getUses() > 0) {
            builder.addText(
                Widgets.AddText.component(
                    0,
                    0,
                    class_2561.method_43469("gui.ls_furniture.jei.chopping_board.chops", recipe.getUses())
                )
                .centered()
                .bounds(66, 10)
                .positionMiddleLeft()
            );

        }

        builder.addTexture(Widgets.AddArrow.Down.progress(0,0).positionCenter());
        builder.addSlot(Widgets.AddSlot.output(0, 0, outputs, 0).positionBottomCenter());

        builder.contentSize(66, 110);
        return builder.build();
    }
}